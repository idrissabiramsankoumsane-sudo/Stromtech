/* Studio de design : le client compose sa maquette (site Web ou application) */
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var COLORS = [["Vert Stromtech", "#087f6b"], ["Bleu", "#2340ff"], ["Vert", "#0f9d6b"], ["Orange", "#f26b1d"], ["Violet", "#7a3cff"], ["Rouge", "#d62839"], ["Noir", "#14161f"]];
  var FONTS = { moderne: ["Moderne", "Figtree,system-ui,sans-serif"], elegante: ["Élégante", "Georgia,'Times New Roman',serif"], affirmee: ["Affirmée", "'Bricolage Grotesque',Figtree,sans-serif"] };
  var RADII = { "0": ["Carrés", "0px"], "1": ["Arrondis", "12px"], "2": ["Très arrondis", "24px"] };
  var SEC = {
    cv: { profil: "Profil", experience: "Expériences", formation: "Formation", competences: "Compétences", contact: "Contact" },
    poster: { evenement: "Événement", accroche: "Accroche", infos: "Informations", contact: "Contact" },
    site: { about: "À propos", services: "Services", produits: "Produits", galerie: "Galerie", tarifs: "Tarifs", temoignages: "Témoignages", contact: "Contact" },
    app: { accueil: "Accueil", catalogue: "Catalogue", commande: "Panier", rdv: "Rendez-vous", messages: "Messages", profil: "Profil" }
  };
  var TPL = {
    site: {
      blank: { label: "Page vierge", desc: "Une page vide à construire librement, bloc par bloc.", hero: "blank", sections: [] },
      vitrine: { label: "Vitrine", desc: "Présenter une activité : restaurant, salon, entreprise.", hero: "center", sections: ["about", "services", "galerie", "contact"] },
      portfolio: { label: "Portfolio", desc: "Montrer ses réalisations : artiste, photographe, freelance.", hero: "left", sections: ["about", "galerie", "temoignages", "contact"] },
      boutique: { label: "Boutique", desc: "Vendre des produits avec un catalogue.", hero: "banner", tag: "Vente en ligne", sections: ["produits", "temoignages", "contact"] },
      landing: { label: "Page de conversion", desc: "Présenter une offre et guider les visiteurs vers une action.", hero: "left", tag: "Offre & contact", sections: ["about", "services", "tarifs", "contact"] },
      evenement: { label: "Événement", desc: "Promouvoir une cérémonie, une activité ou un événement.", hero: "banner", tag: "Promotion", sections: ["about", "galerie", "tarifs", "contact"] }
    },
    cv: {
      classique: { label: "Classique", desc: "CV sobre et professionnel.", sections: ["profil", "experience", "formation", "competences", "contact"] },
      moderne: { label: "Moderne", desc: "CV contemporain avec colonne latérale.", sections: ["profil", "competences", "experience", "formation", "contact"] },
      minimal: { label: "Minimaliste", desc: "Une présentation épurée et lisible.", sections: ["profil", "experience", "competences", "formation"] }
    },
    poster: (function () { var o = {}; Object.keys(window.PosterCanvas.TPLS).forEach(function (k) { var t = window.PosterCanvas.TPLS[k]; o[k] = { label: t.n, desc: t.d, sections: ["evenement", "infos", "contact"] }; }); return o; })(),
    app: {
      commandes: { label: "Commandes", desc: "Catalogue, panier et suivi des commandes.", sections: ["accueil", "catalogue", "commande", "messages", "profil"] },
      rendezvous: { label: "Rendez-vous", desc: "Réservation de créneaux et messagerie.", sections: ["accueil", "rdv", "messages", "profil"] },
      gestion: { label: "Gestion", desc: "Suivre un catalogue, un stock ou des clients.", tag: "Espace professionnel", sections: ["accueil", "catalogue", "messages", "profil"] },
      livraison: { label: "Livraison", desc: "Présenter des articles, prendre les commandes et suivre les échanges.", tag: "Commerce mobile", sections: ["accueil", "catalogue", "commande", "messages", "profil"] },
      education: { label: "Éducation", desc: "Organiser des contenus, rendez-vous et échanges avec les apprenants.", tag: "Formation", sections: ["accueil", "catalogue", "rdv", "messages", "profil"] }
    }
  };
  (function () {
    var P = window.StudioPresets; if (!P) return;
    ["site", "app"].forEach(function (type) { Object.keys(P[type]).forEach(function (k) { var m = P[type][k]; TPL[type][k] = { label: m.label, desc: m.desc, tag: m.tag, hero: m.hero, sections: m.sections.slice(), preset: m.preset }; }); });
    Object.keys(P.appSections).forEach(function (k) { SEC.app[k] = P.appSections[k]; });
  })();
  var lastPresetSlogan = "";
  function clone(x) { return JSON.parse(JSON.stringify(x)); }
  function applyTemplatePreset(prev, t) {
    var p = t.preset, had = prev && prev.preset;
    if (!p && !had) return;
    state.content = {}; state.elementColors = {}; state.productDetails = []; state.serviceDetails = []; state.pricingDetails = []; state.testimonialDetails = [];
    if (p) {
      state.color = p.color; state.theme = p.theme; state.font = p.font; state.radius = p.radius;
      Object.keys(p.content || {}).forEach(function (k) { state.content[k] = p.content[k]; });
      ["productDetails", "serviceDetails", "pricingDetails", "testimonialDetails"].forEach(function (f) { if (p[f]) state[f] = clone(p[f]); });
      if (!state.slogan || state.slogan === lastPresetSlogan) { state.slogan = p.slogan || ""; lastPresetSlogan = p.slogan || ""; }
    } else if (state.slogan === lastPresetSlogan) { state.slogan = ""; lastPresetSlogan = ""; }
  }
  var KEY = "stromtech_studio_draft";
  var state;
  var viewport = "desktop";
  var selectedKey = null;

  function defaults(type, tpl) {
    type = type || "site"; tpl = tpl || ({site:"vitrine",app:"commandes",cv:"classique",poster:"blank"}[type] || "vitrine");
    return { type: type, template: tpl, posterFormat: "portrait", canvas: null, posterVisualHeight: 310, posterImageFit: "cover", name: "", brandMode: "name", brandLogo: "", brandLogoWidth: 150, brandLogoBorder: false, brandLogoBorderColor: "#dce3f5", brandLogoBorderWidth: 1, slogan: "", color: "#087f6b", font: "moderne", radius: "1", theme: "light", sections: TPL[type][tpl].sections.slice(), notes: "", content: {}, elementColors: {}, blocks: [], blockOffsets: {}, blockPositions: {}, blockSizes: {}, blockStyles: {}, imageStyles: {}, imageData: {}, imageWidths: {}, sectionImages: { galerie: [], produits: [] }, sectionImageSettings: { galerie: { fit: "cover", height: 150 }, produits: { fit: "contain", height: 120 } }, productDetails: [], serviceDetails: [], pricingDetails: [], testimonialDetails: [], contactDetails: { nameLabel: "Nom", firstNameLabel: "Prénom", phoneLabel: "Téléphone", emailLabel: "E-mail", buttonLabel: "Envoyer" } };
  }
  function clean(o) {
    var safeType = o && ["site","app","cv","poster"].indexOf(o.type) >= 0 ? o.type : "site";
    var d = defaults(safeType);
    if (!o || typeof o !== "object") return d;
    if (TPL[d.type] && TPL[d.type][o.template]) { d.template = o.template; d.sections = TPL[d.type][o.template].sections.slice(); }
    if (typeof o.name === "string") d.name = o.name.slice(0, 60);
    if (o.brandMode === "logo" && typeof o.brandLogo === "string" && /^data:image\/webp;base64,[A-Za-z0-9+/=]+$/.test(o.brandLogo) && o.brandLogo.length < 250000) { d.brandMode = "logo"; d.brandLogo = o.brandLogo; }
    if (typeof o.brandLogoWidth === "number" && isFinite(o.brandLogoWidth)) d.brandLogoWidth = Math.max(60, Math.min(260, o.brandLogoWidth));
    if (typeof o.brandLogoBorder === "boolean") d.brandLogoBorder = o.brandLogoBorder;
    if (/^#[0-9a-f]{6}$/i.test(o.brandLogoBorderColor)) d.brandLogoBorderColor = o.brandLogoBorderColor;
    if (typeof o.brandLogoBorderWidth === "number" && isFinite(o.brandLogoBorderWidth)) d.brandLogoBorderWidth = Math.max(1, Math.min(8, o.brandLogoBorderWidth));
    if (typeof o.slogan === "string") d.slogan = o.slogan.slice(0, 120);
    if (["portrait","square","story","landscape","a4"].indexOf(o.posterFormat) >= 0) d.posterFormat = o.posterFormat;
    if (typeof o.posterVisualHeight === "number" && isFinite(o.posterVisualHeight)) d.posterVisualHeight = Math.max(120, Math.min(460, o.posterVisualHeight));
    if (o.posterImageFit === "contain" || o.posterImageFit === "cover") d.posterImageFit = o.posterImageFit;
    if (o.canvas && typeof o.canvas === "object" && Array.isArray(o.canvas.els)) {
      var cx = o.canvas, hx = function (v) { return typeof v === "string" && /^#[0-9a-f]{6}$/i.test(v) ? v : ""; }, nm = function (v, a, b, f) { return typeof v === "number" && isFinite(v) ? Math.max(a, Math.min(b, v)) : f; }, imgs = 0;
      d.canvas = { W: nm(cx.W, 200, 1200, 560), H: nm(cx.H, 200, 1400, 700), bg: hx(cx.bg) || "#ffffff", bg2: hx(cx.bg2), angle: nm(cx.angle, 0, 360, 160), els: [] };
      cx.els.slice(0, 40).forEach(function (e) {
        if (!e || typeof e !== "object" || !/^e[0-9]{1,6}$/.test(e.id) || (e.k !== "t" && e.k !== "i")) return;
        var z = { id: e.id, k: e.k, x: nm(e.x, -2000, 2000, 0), y: nm(e.y, -2000, 2000, 0), w: nm(e.w, 8, 2400, 100), h: nm(e.h, 8, 2400, 40), rot: nm(e.rot, -180, 180, 0), op: nm(e.op, 5, 100, 100), rad: nm(e.rad, 0, 999, 0), bg: hx(e.bg), ac: e.ac ? 1 : 0, sp: ["tri","star","diamond","hex","arrow","plus","balloon","arch","oval"].indexOf(e.sp) >= 0 ? e.sp : "", fx: ["shadow","glow","outline","relief","gold","rosegold","silver"].indexOf(e.fx) >= 0 ? e.fx : "", ls: nm(e.ls, 0, 60, 0), lh: nm(e.lh, 0, 3, 0), gr: (window.PosterCanvas.GRADS && Object.prototype.hasOwnProperty.call(window.PosterCanvas.GRADS, e.gr)) ? e.gr : "", ph: e.ph ? 1 : 0, fc: hx(e.fc) || "#ff2bd6", bd: hx(e.bd), bw: nm(e.bw, 0, 30, 0), fl: ["bw","sepia","blur","dark","vivid"].indexOf(e.fl) >= 0 ? e.fl : "" };
        if (e.k === "i") { if (imgs >= 6 || typeof e.src !== "string" || (e.src !== "" && (!/^data:image\/webp;base64,[A-Za-z0-9+/=]+$/.test(e.src) || e.src.length > 500000))) return; imgs++; z.src = e.src; }
        else { z.tx = typeof e.tx === "string" ? e.tx.slice(0, 300) : ""; z.fs = nm(e.fs, 8, 200, 18); z.fw = e.fw >= 700 ? 700 : 400; z.fi = e.fi ? 1 : 0; z.ff = window.PosterCanvas.FONTS.indexOf(e.ff) >= 0 ? e.ff : "Figtree"; z.c = hx(e.c) || "#14161f"; z.al = ["left","center","right"].indexOf(e.al) >= 0 ? e.al : "left"; }
        d.canvas.els.push(z);
      });
    }
    if (typeof o.notes === "string") d.notes = o.notes.slice(0, 1000);
    if (/^#[0-9a-f]{6}$/i.test(o.color)) d.color = o.color;
    if (FONTS[o.font]) d.font = o.font;
    if (RADII[o.radius]) d.radius = o.radius;
    if (o.theme === "dark") d.theme = "dark";
    if (Array.isArray(o.sections)) { var ok = o.sections.filter(function (k) { return SEC[d.type][k]; }); if (ok.length) d.sections = ok.slice(0, d.type === "app" ? 5 : 7); }
    if (o.content && typeof o.content === "object") Object.keys(o.content).slice(0, 60).forEach(function (k) { if (/^[a-zA-Z0-9_-]{1,60}$/.test(k) && typeof o.content[k] === "string") d.content[k] = o.content[k].slice(0, 200); });
    if (o.elementColors && typeof o.elementColors === "object") Object.keys(o.elementColors).slice(0, 60).forEach(function (k) { if (/^[a-zA-Z0-9_-]{1,60}$/.test(k) && /^#[0-9a-f]{6}$/i.test(o.elementColors[k])) d.elementColors[k] = o.elementColors[k]; });
    if (Array.isArray(o.blocks)) d.blocks = o.blocks.slice(0, 30).filter(function (b) { return b && typeof b.id === "string" && /^block_[0-9]{1,16}$/.test(b.id) && (b.type === "text" || b.type === "button" || b.type === "image" || b.type === "shape") && (b.type !== "image" || (o.imageData && typeof o.imageData[b.id] === "string" && o.imageData[b.id].indexOf("data:image/webp;base64,") === 0 && o.imageData[b.id].length < 500000)); }).map(function (b) { return { id: b.id, type: b.type }; });
    if (o.imageData && typeof o.imageData === "object") Object.keys(o.imageData).slice(0, 3).forEach(function (k) { if (/^block_[0-9]{1,16}$/.test(k) && typeof o.imageData[k] === "string" && /^data:image\/webp;base64,[A-Za-z0-9+/=]+$/.test(o.imageData[k]) && o.imageData[k].length < 500000) d.imageData[k] = o.imageData[k]; });
    if (o.imageWidths && typeof o.imageWidths === "object") Object.keys(o.imageWidths).slice(0, 3).forEach(function (k) { if (/^block_[0-9]{1,16}$/.test(k) && typeof o.imageWidths[k] === "number" && isFinite(o.imageWidths[k])) d.imageWidths[k] = Math.max(15, Math.min(100, o.imageWidths[k])); });
    if (o.sectionImages && typeof o.sectionImages === "object") ["galerie","produits"].forEach(function (k) { if (Array.isArray(o.sectionImages[k])) d.sectionImages[k] = o.sectionImages[k].slice(0, 8).filter(function (v) { return typeof v === "string" && /^data:image\/webp;base64,[A-Za-z0-9+/=]+$/.test(v) && v.length < 180000; }); });
    if (Array.isArray(o.productDetails)) d.productDetails = o.productDetails.slice(0,8).map(function(p){p=p&&typeof p==="object"?p:{};return {name:typeof p.name==="string"?p.name.slice(0,60):"",price:typeof p.price==="string"?p.price.slice(0,30):"",description:typeof p.description==="string"?p.description.slice(0,140):""};});
    if (Array.isArray(o.serviceDetails)) d.serviceDetails = o.serviceDetails.slice(0,6).map(function(p){p=p&&typeof p==="object"?p:{};return {name:typeof p.name==="string"?p.name.slice(0,60):"",description:typeof p.description==="string"?p.description.slice(0,140):""};});
    if (Array.isArray(o.pricingDetails)) d.pricingDetails = o.pricingDetails.slice(0,6).map(function(p){p=p&&typeof p==="object"?p:{};return {name:typeof p.name==="string"?p.name.slice(0,60):"",price:typeof p.price==="string"?p.price.slice(0,30):"",description:typeof p.description==="string"?p.description.slice(0,140):""};});
    if (Array.isArray(o.testimonialDetails)) d.testimonialDetails = o.testimonialDetails.slice(0,6).map(function(p){p=p&&typeof p==="object"?p:{};return {quote:typeof p.quote==="string"?p.quote.slice(0,240):"",author:typeof p.author==="string"?p.author.slice(0,60):""};});
    if (o.contactDetails && typeof o.contactDetails === "object") { [["nameLabel",60],["firstNameLabel",60],["phoneLabel",60],["emailLabel",60],["buttonLabel",40]].forEach(function(f){if(typeof o.contactDetails[f[0]]==="string")d.contactDetails[f[0]]=o.contactDetails[f[0]].slice(0,f[1]);}); }
    if (o.sectionImageSettings && typeof o.sectionImageSettings === "object") ["galerie","produits"].forEach(function (k) { var v=o.sectionImageSettings[k]; if (!v || typeof v !== "object") return; d.sectionImageSettings[k].fit = ["cover","contain"].indexOf(v.fit)>=0 ? v.fit : d.sectionImageSettings[k].fit; if (typeof v.height==="number" && isFinite(v.height)) d.sectionImageSettings[k].height=Math.max(80,Math.min(260,v.height)); });
    if (o.imageStyles && typeof o.imageStyles === "object") Object.keys(o.imageStyles).slice(0, 3).forEach(function (k) { var v=o.imageStyles[k]; if (!/^block_[0-9]{1,16}$/.test(k) || !v || typeof v !== "object") return; var z={}; if (["contain","cover","fill"].indexOf(v.fit)>=0) z.fit=v.fit; if (typeof v.radius==="number" && isFinite(v.radius)) z.radius=Math.max(0,Math.min(40,v.radius)); if (typeof v.border==="boolean") z.border=v.border; if (/^#[0-9a-f]{6}$/i.test(v.borderColor)) z.borderColor=v.borderColor; d.imageStyles[k]=z; });
    if (o.blockOffsets && typeof o.blockOffsets === "object") Object.keys(o.blockOffsets).slice(0, 30).forEach(function (k) { if (/^block_[0-9]{1,16}$/.test(k) && typeof o.blockOffsets[k] === "number" && isFinite(o.blockOffsets[k])) d.blockOffsets[k] = Math.max(-45, Math.min(45, o.blockOffsets[k])); });
    if (o.blockPositions && typeof o.blockPositions === "object") Object.keys(o.blockPositions).slice(0, 30).forEach(function (k) { var p = o.blockPositions[k]; if (/^block_[0-9]{1,16}$/.test(k) && p && typeof p.x === "number" && typeof p.y === "number" && isFinite(p.x) && isFinite(p.y)) d.blockPositions[k] = { x: Math.max(-1200, Math.min(1200, p.x)), y: Math.max(-1200, Math.min(1200, p.y)) }; });
    if (o.blockSizes && typeof o.blockSizes === "object") Object.keys(o.blockSizes).slice(0, 30).forEach(function (k) { var z = o.blockSizes[k]; if (/^block_[0-9]{1,16}$/.test(k) && z && typeof z.w === "number" && typeof z.h === "number" && isFinite(z.w) && isFinite(z.h)) d.blockSizes[k] = { w: Math.max(48, Math.min(1200, z.w)), h: Math.max(40, Math.min(900, z.h)) }; });
    if (o.blockStyles && typeof o.blockStyles === "object") Object.keys(o.blockStyles).slice(0, 30).forEach(function (k) { var s = o.blockStyles[k]; if (!/^block_[0-9]{1,16}$/.test(k) || !s || typeof s !== "object") return; var cleanStyle = {}; if (typeof s.fontSize === "number" && isFinite(s.fontSize)) cleanStyle.fontSize = Math.max(12, Math.min(48, s.fontSize)); if (["left", "center", "right"].indexOf(s.textAlign) >= 0) cleanStyle.textAlign = s.textAlign; if (["normal", "600", "700"].indexOf(String(s.fontWeight)) >= 0) cleanStyle.fontWeight = String(s.fontWeight); if (typeof s.italic === "boolean") cleanStyle.italic = s.italic; if (typeof s.underline === "boolean") cleanStyle.underline = s.underline; if (typeof s.letterSpacing === "number" && isFinite(s.letterSpacing)) cleanStyle.letterSpacing = Math.max(-1, Math.min(8, s.letterSpacing)); if (typeof s.lineHeight === "number" && isFinite(s.lineHeight)) cleanStyle.lineHeight = Math.max(1, Math.min(2.2, s.lineHeight)); if (typeof s.fontFamily === "string" && ["Arial, sans-serif","Georgia, serif","'Trebuchet MS', sans-serif","'Courier New', monospace","system-ui, sans-serif"].indexOf(s.fontFamily) >= 0) cleanStyle.fontFamily = s.fontFamily; if (/^#[0-9a-f]{6}$/i.test(s.backgroundColor)) cleanStyle.backgroundColor = s.backgroundColor; if (typeof s.radius === "number" && isFinite(s.radius)) cleanStyle.radius = Math.max(0, Math.min(32, s.radius)); d.blockStyles[k] = cleanStyle; });
    return d;
  }
  var pages = [], activePageId = null;
  var PAGE_FIELDS = ["template", "sections", "content", "elementColors", "blocks", "blockOffsets", "blockPositions", "blockSizes", "blockStyles", "imageStyles", "imageData", "imageWidths", "sectionImages", "sectionImageSettings", "productDetails", "serviceDetails", "pricingDetails", "testimonialDetails", "contactDetails"];
  function pageSnapshot(source) {
    var snap = {};
    PAGE_FIELDS.forEach(function (k) { snap[k] = source[k] instanceof Array ? source[k].slice() : (source[k] && typeof source[k] === "object" ? JSON.parse(JSON.stringify(source[k])) : source[k]); });
    return snap;
  }
  function storeCurrentPage() {
    if (!pages.length) return;
    var page = pages.find(function (p) { return p.id === activePageId; });
    if (page) page.data = pageSnapshot(state);
  }
  function applyPage(page) {
    if (!page) return;
    PAGE_FIELDS.forEach(function (k) {
      var value = page.data[k];
      state[k] = value instanceof Array ? value.slice() : (value && typeof value === "object" ? JSON.parse(JSON.stringify(value)) : value);
    });
    activePageId = page.id; selectedKey = null; appTab = null;
  }
  function initPages(raw) {
    pages = [];
    if (raw && Array.isArray(raw.pages)) {
      raw.pages.slice(0, 10).forEach(function (p, i) {
        if (!p || typeof p.id !== "string" || !p.data || typeof p.data !== "object") return;
        var base = clean(Object.assign({}, state, p.data));
        pages.push({ id: p.id.slice(0, 40), name: (typeof p.name === "string" ? p.name : "Page " + (i + 1)).slice(0, 40), data: pageSnapshot(base) });
      });
    }
    if (!pages.length) pages.push({ id: "page_" + Date.now(), name: "Page 1", data: pageSnapshot(state) });
    var wanted = raw && typeof raw.activePageId === "string" ? raw.activePageId : "";
    var active = pages.find(function (p) { return p.id === wanted; }) || pages[0];
    applyPage(active);
  }
  function exportState() {
    storeCurrentPage();
    var out = Object.assign({}, state, { pages: pages, activePageId: activePageId });
    return out;
  }
  function renderPages() {
    var host = $("pageList"); if (!host) return;
    host.textContent = "";
    pages.forEach(function (page) {
      var b = el("button", "page-tab" + (page.id === activePageId ? " is-active" : ""), page.name);
      b.type = "button"; b.setAttribute("aria-pressed", String(page.id === activePageId));
      b.addEventListener("click", function () { switchPage(page.id); });
      host.appendChild(b);
    });
    $("pageStatus").textContent = pages.length + " page" + (pages.length > 1 ? "s" : "") + " · maximum 10";
    $("duplicatePage").disabled = pages.length >= 10;
    $("addPage").disabled = pages.length >= 10;
    $("deletePage").disabled = pages.length <= 1;
  }
  function switchPage(id) {
    storeCurrentPage();
    var target = pages.find(function (p) { return p.id === id; });
    if (!target) return;
    applyPage(target); buildControls(); render(); renderPages(); saveDraft();
  }
  function createPage(copyCurrent) {
    if (pages.length >= 10) return;
    storeCurrentPage();
    var data = copyCurrent ? pageSnapshot(state) : pageSnapshot(defaults(state.type));
    var n = pages.length + 1, page = { id: "page_" + Date.now(), name: "Page " + n, data: data };
    pages.push(page); applyPage(page); buildControls(); render(); renderPages(); saveDraft();
  }
  function renameCurrentPage() {
    var page = pages.find(function (p) { return p.id === activePageId; });
    if (!page) return;
    var value = window.prompt("Nouveau nom de la page :", page.name);
    if (value === null) return;
    value = value.trim().slice(0, 40);
    if (!value) return window.alert("Le nom de la page ne peut pas être vide.");
    page.name = value; renderPages(); saveDraft();
  }
  function deleteCurrentPage() {
    if (pages.length <= 1) return;
    var index = pages.findIndex(function (p) { return p.id === activePageId; });
    if (index < 0 || !window.confirm("Supprimer « " + pages[index].name + " » ? Cette action ne concerne que cette page.")) return;
    pages.splice(index, 1);
    var next = pages[Math.max(0, index - 1)]; applyPage(next);
    buildControls(); render(); renderPages(); saveDraft();
  }
  function b64u(bytes) { var s = ""; for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]); return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); }
  function unb64u(s) { s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "="; var b = atob(s), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  async function pipeBytes(bytes, Ctor) { var st = new Blob([bytes]).stream().pipeThrough(new Ctor("deflate-raw")); return new Uint8Array(await new Response(st).arrayBuffer()); }
  async function enc(o) {
    var json = new TextEncoder().encode(JSON.stringify(o));
    if (window.CompressionStream) { try { return "z" + b64u(await pipeBytes(json, CompressionStream)); } catch (e) {} }
    return b64u(json);
  }
  async function dec(s) {
    var bytes;
    if (s.charAt(0) === "z") { if (!window.DecompressionStream) throw new Error("Navigateur trop ancien pour ouvrir ce lien."); bytes = await pipeBytes(unb64u(s.slice(1)), DecompressionStream); }
    else bytes = unb64u(s);
    return JSON.parse(new TextDecoder().decode(bytes));
  }
  /* Les images ne voyagent pas dans le lien : elles sont jointes à la conversation. */
  function stripImages(o) {
    var c = JSON.parse(JSON.stringify(o));
    (function walk(x) {
      if (!x || typeof x !== "object") return;
      if (Array.isArray(x)) { x.forEach(walk); return; }
      if ("imageData" in x) x.imageData = {};
      if ("brandLogo" in x) { x.brandLogo = ""; if (x.brandMode === "logo") x.brandMode = "name"; }
      if (Array.isArray(x.els)) x.els.forEach(function (e) { if (e && e.k === "i") e.src = ""; });
      if ("sectionImages" in x) x.sectionImages = { galerie: [], produits: [] };
      Object.keys(x).forEach(function (k) { if (x[k] && typeof x[k] === "object") walk(x[k]); });
    })(c);
    return c;
  }
  function collectImages(o) {
    var list = [], seen = {};
    function add(d, n) { if (typeof d === "string" && /^data:image\/webp;base64,[A-Za-z0-9+\/=]+$/.test(d) && !seen[d] && list.length < 8) { seen[d] = 1; list.push({ data: d, name: n }); } }
    (function walk(x) {
      if (!x || typeof x !== "object") return;
      if (x.brandLogo) add(x.brandLogo, "logo.webp");
      if (x.imageData && typeof x.imageData === "object") Object.keys(x.imageData).forEach(function (k) { add(x.imageData[k], "image-" + (list.length + 1) + ".webp"); });
      if (x.canvas && Array.isArray(x.canvas.els)) x.canvas.els.forEach(function (e) { if (e && e.k === "i") add(e.src, "affiche-image-" + (list.length + 1) + ".webp"); });
      if (x.sectionImages) ["galerie", "produits"].forEach(function (k) { (x.sectionImages[k] || []).forEach(function (d) { add(d, k + "-" + (list.length + 1) + ".webp"); }); });
      if (Array.isArray(x.pages)) x.pages.forEach(function (p) { walk(p && p.data); });
    })(o);
    return list;
  }
  function dataToBlob(d) { var b = atob(d.split(",")[1]), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return new Blob([a], { type: "image/webp" }); }
  function draftKey(type) { return KEY + "_" + type; }
  function saveDraft() { try { localStorage.setItem(draftKey(state.type), JSON.stringify(exportState())); } catch (e) {} }
  function loadDraft(type) {
    try {
      var saved = JSON.parse(localStorage.getItem(draftKey(type)));
      if (saved) return saved;
      var legacy = JSON.parse(localStorage.getItem(KEY));
      return legacy && legacy.type === type ? legacy : null;
    } catch (e) { return null; }
  }

  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function lines(n) { var f = document.createDocumentFragment(); for (var i = 0; i < n; i++) { var l = el("div", "pv-line"); l.style.width = (100 - i * 14) + "%"; f.appendChild(l); } return f; }
  function editText(tag, cls, value, key, label) {
    var node = el(tag, cls, state.content[key] != null ? state.content[key] : value);
    node.dataset.editable = key;
    node.dataset.editLabel = label;
    if (state.elementColors[key]) node.style.color = state.elementColors[key];
    return node;
  }
  function updateInspector() {
    var empty = $("inspectorEmpty"), fields = $("inspectorFields");
    var node = selectedKey && $("pv").querySelector('[data-editable="' + selectedKey + '"]');
    if (!node) { selectedKey = null; empty.hidden = false; fields.hidden = true; $("blockActions").hidden = true; return; }
    empty.hidden = true; fields.hidden = false;
    $("selectedElementName").textContent = node.dataset.editLabel || "Élément";
    $("elementText").value = state.content[selectedKey] != null ? state.content[selectedKey] : node.textContent;
    $("elementColor").value = state.elementColors[selectedKey] || "#14161f";
    var selectedBlock = state.blocks.find(function (b) { return b.id === selectedKey; });
    var isImage = selectedBlock && selectedBlock.type === "image";
    var isShape = selectedBlock && selectedBlock.type === "shape";
    $("elementTextLabel").hidden = !!isImage || !!isShape; $("elementText").hidden = !!isImage || !!isShape;
    $("elementColorLabel").hidden = !!isImage || !!isShape; $("elementColor").hidden = !!isImage || !!isShape;
    $("imageSizeGroup").hidden = !isImage;
    if (isImage) {
      $("imageWidth").value = state.imageWidths[selectedKey] || 60;
      var imageStyle = state.imageStyles[selectedKey] || {};
      $("imageFit").value = imageStyle.fit || "contain";
      $("imageRadius").value = imageStyle.radius == null ? 0 : imageStyle.radius;
      $("imageRadiusValue").textContent = $("imageRadius").value + " px";
      $("imageBorder").checked = !!imageStyle.border;
      $("imageBorderColor").value = imageStyle.borderColor || "#dce2ee";
      $("imageBorderColor").disabled = !imageStyle.border;
    }
    $("blockActions").hidden = !selectedBlock;
    var alignGroup = $("blockAlignGroup");
    if (alignGroup) alignGroup.hidden = !selectedBlock;
    var positionGroup = $("blockPositionGroup");
    if (positionGroup) {
      positionGroup.hidden = !selectedBlock;
      var position = state.blockPositions[selectedKey] || { x: 0, y: 0 };
      $("blockPositionX").value = position.x; $("blockPositionY").value = position.y;
      $("blockPositionXValue").textContent = position.x + " px"; $("blockPositionYValue").textContent = position.y + " px";
    }
    var styleGroup = $("blockStyleGroup");
    if (styleGroup) {
      styleGroup.hidden = !selectedBlock || isImage;
      var style = state.blockStyles[selectedKey] || {};
      $("blockFontSize").value = style.fontSize || 16;
      $("blockFontSizeValue").textContent = (style.fontSize || 16) + " px";
      $("blockTextAlign").value = style.textAlign || "left";
      $("blockFontWeight").value = style.fontWeight || "normal";
      $("blockFontFamily").value = style.fontFamily || "Arial, sans-serif";
      $("blockItalic").checked = !!style.italic;
      $("blockUnderline").checked = !!style.underline;
      $("blockLetterSpacing").value = style.letterSpacing || 0;
      $("blockLetterSpacingValue").textContent = (style.letterSpacing || 0) + " px";
      $("blockLineHeight").value = style.lineHeight || 1.4;
      $("blockLineHeightValue").textContent = Number($("blockLineHeight").value).toFixed(1);
      $("blockBackground").value = style.backgroundColor || "#2340ff";
      $("blockRadius").value = style.radius == null ? 12 : style.radius;
      $("blockRadiusValue").textContent = $("blockRadius").value + " px";
    }
  }

  function renderCustomBlocks(root) {
    if (!state.blocks.length) return;
    var wrap = el("section", "pv-custom-blocks");
    state.blocks.forEach(function (block) {
      var key = block.id;
      var item = el("div", "pv-custom-item");
      item.dataset.blockId = block.id;
      var node;
      if (block.type === "image") {
        node = el("img", "pv-custom-image");
        node.src = state.imageData[key] || "";
        node.alt = state.content[key] || "Image ajoutée";
        node.style.width = (state.imageWidths[key] || 60) + "%";
        node.dataset.editable = key; node.dataset.editLabel = "Image / logo";
      } else if (block.type === "shape") {
        node = el("div", "pv-custom-shape"); node.dataset.editable = key; node.dataset.editLabel = "Forme graphique"; node.setAttribute("role", "img"); node.setAttribute("aria-label", "Forme graphique");
      } else {
        node = block.type === "button" ? editText("button", "pv-btn pv-custom-button", state.content[key] != null ? state.content[key] : "Nouveau bouton", key, "Bloc bouton") : editText("p", "pv-custom-text", state.content[key] != null ? state.content[key] : "Ton nouveau texte", key, "Bloc texte");
      }
      var pos = state.blockPositions[block.id] || { x: 0, y: 0 };
      var offset = state.blockOffsets[block.id] || 0;
      item.style.transform = "translate3d(" + (pos.x + offset / 100 * 100) + "px," + pos.y + "px,0)";
      var size = state.blockSizes[block.id];
      if (size) { item.style.width = size.w + "px"; item.style.height = size.h + "px"; }
      else if (block.type === "shape") { item.style.width = "150px"; item.style.height = "90px"; }
      if (block.type === "image") {
        if (!size) item.style.width = (state.imageWidths[key] || 60) + "%";
        node.style.width = "100%"; if (size) node.style.height = "100%";
        var imageStyle = state.imageStyles[key] || {};
        node.style.objectFit = imageStyle.fit || "contain";
        node.style.borderRadius = (imageStyle.radius || 0) + "px";
        node.style.border = imageStyle.border ? "2px solid " + (imageStyle.borderColor || "#dce2ee") : "0";
      }
      if (block.type === "button") node.type = "button";
      if (block.type !== "image") {
        var blockStyle = state.blockStyles[key] || {};
        if (block.type === "shape") { node.style.backgroundColor = blockStyle.backgroundColor || "#38d6b0"; node.style.borderRadius = (blockStyle.radius == null ? 16 : blockStyle.radius) + "px"; node.style.width = "100%"; node.style.height = "100%"; }
        if (blockStyle.fontSize) node.style.fontSize = blockStyle.fontSize + "px";
        if (blockStyle.textAlign) node.style.textAlign = blockStyle.textAlign;
        if (blockStyle.fontWeight) node.style.fontWeight = blockStyle.fontWeight;
        if (blockStyle.fontFamily) node.style.fontFamily = blockStyle.fontFamily;
        if (blockStyle.italic) node.style.fontStyle = "italic";
        if (blockStyle.underline) node.style.textDecoration = "underline";
        if (blockStyle.letterSpacing != null) node.style.letterSpacing = blockStyle.letterSpacing + "px";
        if (blockStyle.lineHeight) node.style.lineHeight = blockStyle.lineHeight;
        if (blockStyle.backgroundColor) node.style.backgroundColor = blockStyle.backgroundColor;
        if (blockStyle.radius != null) node.style.borderRadius = blockStyle.radius + "px";
      }
      item.appendChild(node);
      var handle = el("button", "pv-resize-handle"); handle.type = "button"; handle.setAttribute("aria-label", "Redimensionner cet élément avec les flèches du clavier"); handle.title = "Redimensionner · flèches du clavier";
      handle.addEventListener("keydown", function (event) {
        var steps = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
        var step = steps[event.key];
        if (!step) return;
        event.preventDefault();
        var current = state.blockSizes[key] || { w: Math.round(item.getBoundingClientRect().width), h: Math.round(item.getBoundingClientRect().height) };
        var amount = event.shiftKey ? 30 : 10;
        current.w = Math.max(48, Math.min(1200, current.w + step[0] * amount));
        current.h = Math.max(40, Math.min(900, current.h + step[1] * amount));
        state.blockSizes[key] = current;
        item.style.width = current.w + "px"; item.style.height = current.h + "px";
        if (block.type === "image") { node.style.width = "100%"; node.style.height = "100%"; }
        saveDraft();
      });
      item.appendChild(handle);
      wrap.appendChild(item);
    });
    root.appendChild(wrap);
  }

  function styleBrandLogo(img) {
    img.style.width = state.brandLogoWidth + "px"; img.style.maxWidth = "100%";
    if (state.brandLogoBorder) { img.style.border = state.brandLogoBorderWidth + "px solid " + state.brandLogoBorderColor; img.style.padding = "5px"; img.style.borderRadius = "10px"; }
    else { img.style.border = "0"; img.style.padding = "0"; img.style.borderRadius = "0"; }
    return img;
  }

  /* ---------- Aperçu : site ---------- */
  function previewSite(root) {
    var tpl = TPL.site[state.template], nm = state.name || "Ton entreprise", sl = state.slogan || "Ton slogan s’affiche ici";
    if (state.template === "blank") {
      renderCustomBlocks(root);
      return;
    }
    var nav = el("div", "pv-nav");
    if (state.brandMode === "logo" && state.brandLogo) { var brandImg = styleBrandLogo(el("img", "pv-brand-logo")); brandImg.src = state.brandLogo; brandImg.alt = nm; nav.appendChild(brandImg); }
    else nav.appendChild(editText("b", "", nm, "brandName", "Nom de l’entreprise"));
    var links = el("span", "pv-links"); state.sections.slice(0, 4).forEach(function (k) { links.appendChild(el("span", "", SEC.site[k])); }); nav.appendChild(links);
    nav.appendChild(el("i", "pv-btn", "Contact")); root.appendChild(nav);
    var hero = el("div", "pv-hero pv-" + tpl.hero);
    var box = el("div", "pv-herotxt"); box.appendChild(editText("h4", "pv-h", sl, "heroTitle", "Titre principal")); box.appendChild(editText("p", "", "Une phrase courte pour expliquer ce que tu proposes à tes clients.", "heroDescription", "Description principale")); box.appendChild(editText("i", "pv-btn", tpl.hero === "banner" ? "Voir les nouveautés" : "Nous contacter", "heroButton", "Bouton principal")); hero.appendChild(box);
    if (tpl.hero === "left") hero.appendChild(el("div", "pv-avatar", tpl.preset && tpl.preset.icon || "")); else if (tpl.hero === "split") hero.appendChild(el("div", "pv-deco", tpl.preset && tpl.preset.icon || "★"));
    root.appendChild(hero);
    renderCustomBlocks(root);
    var builders = {
      about: function (b) { b.appendChild(editText("p", "pv-about-description", "Présente ton activité, ton expérience et ce qui te rend unique.", "aboutDescription", "Présentation de ton activité")); },
      services: function (b) { var g = el("div", "pv-grid3"); for (var i=0;i<Math.max(3,state.serviceDetails.length);i++) { var detail=state.serviceDetails[i]||{}; var c=el("div","pv-card"); c.appendChild(el("b","",detail.name||"Service "+(i+1))); if(detail.description)c.appendChild(el("p","pv-product-description",detail.description)); else c.appendChild(lines(2)); g.appendChild(c); } b.appendChild(g); },
      produits: function (b) { var g = el("div", "pv-grid4 pv-user-images"); var imgs = state.sectionImages.produits || []; for (var i = 0; i < Math.max(4, imgs.length); i++) { var c = el("div", "pv-card"); var detail=state.productDetails[i]||{}; if (imgs[i]) { var im = el("img", "pv-section-image pv-product-image"); im.src = imgs[i]; im.alt = detail.name || "Produit " + (i + 1); im.style.height = state.sectionImageSettings.produits.height + "px"; im.style.objectFit = state.sectionImageSettings.produits.fit; c.appendChild(im); } else c.appendChild(el("div", "pv-sq")); c.appendChild(el("b", "", detail.name || "Produit " + (i + 1))); if(detail.description)c.appendChild(el("p","pv-product-description",detail.description)); c.appendChild(el("span", "pv-price", detail.price || ((i * 5 + 5) + " 000 FCFA"))); g.appendChild(c); } b.appendChild(g); },
      galerie: function (b) { var g = el("div", "pv-grid3 pv-user-images"); var imgs = state.sectionImages.galerie || []; for (var i = 0; i < Math.max(6, imgs.length); i++) { if (imgs[i]) { var im = el("img", "pv-section-image pv-gallery-image"); im.src = imgs[i]; im.alt = "Image de galerie " + (i + 1); im.style.height = state.sectionImageSettings.galerie.height + "px"; im.style.objectFit = state.sectionImageSettings.galerie.fit; g.appendChild(im); } else g.appendChild(el("div", "pv-sq")); } b.appendChild(g); },
      tarifs: function (b) { var g = el("div", "pv-grid3"); for(var i=0;i<Math.max(3,state.pricingDetails.length);i++){var detail=state.pricingDetails[i]||{};var c=el("div","pv-card");c.appendChild(el("b","",detail.name||["Basique","Standard","Premium"][i]||"Offre "+(i+1)));c.appendChild(el("span","pv-price",detail.price||"— FCFA"));if(detail.description)c.appendChild(el("p","pv-product-description",detail.description));else c.appendChild(lines(2));g.appendChild(c);} b.appendChild(g); },
      temoignages: function (b) { var g = el("div", "pv-grid2"); for(var i=0;i<Math.max(2,state.testimonialDetails.length);i++){var detail=state.testimonialDetails[i]||{};var c=el("div","pv-card");c.appendChild(el("p","","“"+(detail.quote||"Un travail soigné, livré dans les temps.")+"”"));c.appendChild(el("b","",detail.author||"Prénom Nom"));g.appendChild(c);} b.appendChild(g); },
      contact: function (b) { var c = el("div", "pv-card"); c.appendChild(el("div", "pv-input", state.contactDetails.nameLabel || "Nom")); c.appendChild(el("div", "pv-input", state.contactDetails.firstNameLabel || "Prénom")); c.appendChild(el("div", "pv-input", state.contactDetails.phoneLabel || "Téléphone")); c.appendChild(el("div", "pv-input", state.contactDetails.emailLabel || "E-mail")); c.appendChild(el("i", "pv-btn", state.contactDetails.buttonLabel || "Envoyer")); b.appendChild(c); }
    };
    state.sections.forEach(function (k) { var s = el("section", "pv-sec"); s.appendChild(editText("h5", "", SEC.site[k], "section_" + k, "Titre : " + SEC.site[k])); builders[k](s); root.appendChild(s); });
    root.appendChild(editText("div", "pv-foot", "© " + nm, "footerText", "Pied de page"));
  }


  function previewCV(root) {
    var cv = el("article", "pv-document pv-cv pv-cv-" + state.template);
    var head = el("header", "cv-header");
    var cvPhotoBlock = state.blocks.find(function(b){return b.type==="image" && state.imageData[b.id];});
    if (cvPhotoBlock) { var photo=el("img","cv-photo"); photo.src=state.imageData[cvPhotoBlock.id]; photo.alt="Photo du CV"; head.appendChild(photo); }
    head.appendChild(editText("h2", "", state.name || "Prénom NOM", "cvName", "Nom complet"));
    head.appendChild(editText("p", "", state.slogan || "Intitulé du poste recherché", "cvTitle", "Titre professionnel"));
    cv.appendChild(head);
    var body = el("div", "cv-body");
    var side = el("aside", "cv-side");
    side.appendChild(el("h3", "", "CONTACT"));
    side.appendChild(editText("p", "", "Téléphone · E-mail · Ville", "cvContact", "Coordonnées"));
    side.appendChild(el("h3", "", "COMPÉTENCES"));
    side.appendChild(editText("p", "", "Communication\nOrganisation\nInformatique", "cvSkills", "Compétences"));
    side.appendChild(el("h3", "", "LANGUES"));
    side.appendChild(editText("p", "", "Français · Anglais", "cvLanguages", "Langues"));
    var main = el("div", "cv-main");
    [["PROFIL","cvProfile","Présente-toi en quelques lignes et précise tes points forts."],["EXPÉRIENCES","cvExperience","Poste occupé · Entreprise · Dates\nDécris tes principales missions et réalisations."],["FORMATION","cvEducation","Diplôme · Établissement · Année"],["PROJETS","cvProjects","Ajoute ici tes projets ou certifications."]].forEach(function(x){main.appendChild(el("h3","",x[0]));main.appendChild(editText("p","",x[2],x[1],x[0]));});
    body.appendChild(side); body.appendChild(main); cv.appendChild(body); root.appendChild(cv);
  }
  function previewPoster(root) {
    var F = { portrait: [560, 700], square: [560, 560], story: [420, 746], landscape: [760, 428], a4: [560, 792] }[state.posterFormat] || [560, 700];
    if (!state.canvas) state.canvas = window.PosterCanvas.seed(state.template, F[0], F[1], state.name, state.slogan, state.color);
    window.PosterCanvas.draw(root, state, F[0], F[1], { save: saveDraft });
  }
  function previewPosterOld(root) {
    var poster = el("article", "pv-document pv-poster pv-poster-" + state.template);
    var visual = el("div", "poster-visual");
    visual.style.height = state.posterVisualHeight + "px";
    visual.style.minHeight = state.posterVisualHeight + "px";
    var imageBlock = state.blocks.find(function(b){return b.type==="image" && state.imageData[b.id];});
    if (imageBlock) {
      var im = el("img", "poster-image"); im.src = state.imageData[imageBlock.id]; im.alt = "Visuel principal de l’affiche"; im.style.objectFit = state.posterImageFit; visual.appendChild(im);
    } else {
      visual.appendChild(el("span", "poster-placeholder", "Ajoute une photo ou une illustration avec « Image / logo »"));
    }
    var top = el("header", "poster-top");
    top.appendChild(editText("p", "poster-brand", state.name || "NOM DE LA MARQUE", "posterBrand", "Nom de la marque"));
    top.appendChild(editText("h2", "poster-title", state.slogan || "TON ÉVÉNEMENT", "posterTitle", "Titre principal de l’affiche"));
    top.appendChild(editText("p", "poster-subtitle", "Une phrase courte pour attirer l’attention", "posterSubtitle", "Sous-titre"));
    var info = el("footer", "poster-info");
    info.appendChild(editText("h3", "poster-details", "DATE · HEURE · LIEU", "posterDetails", "Date, heure et lieu"));
    info.appendChild(editText("p", "poster-extra", "Informations complémentaires, tarif ou offre spéciale", "posterExtra", "Informations complémentaires"));
    info.appendChild(editText("b", "poster-contact", "CONTACT · TÉLÉPHONE · RÉSEAUX", "posterContact", "Coordonnées"));
    info.appendChild(editText("span", "poster-cta", "RÉSERVE TA PLACE", "posterCTA", "Appel à l’action"));
    if (state.template === "concert" || state.template === "split" || state.template === "sale") {
      poster.appendChild(visual); poster.appendChild(top); poster.appendChild(info);
    } else {
      poster.appendChild(top); poster.appendChild(visual); poster.appendChild(info);
    }
    root.appendChild(poster);
  }
  /* ---------- Aperçu : application ---------- */
  var appTab = null;
  function previewApp(root) {
    var nm = state.name || "Ton appli", sl = state.slogan || "Ton slogan s’affiche ici";
    if (state.sections.indexOf(appTab) < 0) appTab = state.sections[0];
    var ph = el("div", "phone");
    if (state.brandMode === "logo" && state.brandLogo) { var appLogo = styleBrandLogo(el("img", "pv-brand-logo pv-app-logo")); appLogo.src = state.brandLogo; appLogo.alt = nm; ph.appendChild(appLogo); }
    else ph.appendChild(editText("div", "pv-appbar", nm, "appName", "Nom de l’application"));
    var scr = el("div", "pv-screen");
    var S = {
      accueil: function () { scr.appendChild(editText("h4", "pv-h", "Bonjour", "appGreeting", "Titre d’accueil")); scr.appendChild(editText("p", "", sl, "appSlogan", "Slogan de l’application")); var c = el("div", "pv-card pv-accent"); c.appendChild(el("b", "", "Offre du moment")); c.appendChild(lines(2)); scr.appendChild(c); var g = el("div", "pv-grid2"); ["Action 1", "Action 2"].forEach(function (t) { var x = el("div", "pv-card"); x.appendChild(el("b", "", t)); g.appendChild(x); }); scr.appendChild(g); },
      catalogue: function () { [1, 2, 3].forEach(function (i) { var r = el("div", "pv-row"); r.appendChild(el("div", "pv-thumb")); var m = el("div", "pv-grow"); m.appendChild(el("b", "", "Article " + i)); m.appendChild(lines(1)); r.appendChild(m); r.appendChild(el("span", "pv-price", (i * 2 + 3) + " 000")); scr.appendChild(r); }); },
      commande: function () { [1, 2].forEach(function (i) { var r = el("div", "pv-row"); r.appendChild(el("div", "pv-thumb")); r.appendChild(el("b", "pv-grow", "Article " + i + " × 1")); r.appendChild(el("span", "pv-price", (i * 2 + 3) + " 000")); scr.appendChild(r); }); scr.appendChild(el("p", "", "Total : 12 000 FCFA")); scr.appendChild(el("i", "pv-btn pv-full", "Commander")); },
      rdv: function () { var d = el("div", "pv-days"); ["Lun", "Mar", "Mer", "Jeu", "Ven"].forEach(function (x, i) { d.appendChild(el("span", i === 1 ? "on" : "", x)); }); scr.appendChild(d); var t = el("div", "pv-grid3"); ["09:00", "10:30", "14:00", "15:30", "16:00", "17:30"].forEach(function (x, i) { t.appendChild(el("span", "pv-slot" + (i === 2 ? " on" : ""), x)); }); scr.appendChild(t); scr.appendChild(el("i", "pv-btn pv-full", "Réserver")); },
      messages: function () { scr.appendChild(el("div", "pv-bub", "Bonjour, comment puis-je t’aider ?")); scr.appendChild(el("div", "pv-bub me", "Je voudrais plus d’informations.")); scr.appendChild(el("div", "pv-input", "Écris ton message")); },
      profil: function () { scr.appendChild(el("div", "pv-avatar pv-center")); scr.appendChild(el("h4", "pv-h pv-ctr", "Ton profil")); ["Mes informations", "Mes commandes", "Aide"].forEach(function (t) { scr.appendChild(el("div", "pv-row", t)); }); }
    };
    var SC = (window.StudioPresets && window.StudioPresets.screens) || {};
    Object.keys(SC).forEach(function (k) { S[k] = function () { SC[k](scr, el, state); }; });
    var origHome = S.accueil;
    S.accueil = function () { var pt = TPL.app[state.template] && TPL.app[state.template].preset; if (pt && pt.home && window.StudioPresets.home) window.StudioPresets.home(scr, el, state, pt.home, editText, sl); else origHome(); };
    (S[appTab] || S.accueil)(); renderCustomBlocks(scr); ph.appendChild(scr);
    var bar = el("div", "pv-tabs");
    state.sections.forEach(function (k) { var b = el("button", k === appTab ? "on" : "", SEC.app[k]); b.type = "button"; b.addEventListener("click", function () { appTab = k; render(); }); bar.appendChild(b); });
    ph.appendChild(bar); root.appendChild(ph);
  }

  function render() {
    var root = $("pv");
    if (state.type !== "poster" && window.PosterCanvas.release) window.PosterCanvas.release();
    $("posterExport").hidden = state.type !== "cv";
    
    $("posterOptions").hidden = state.type !== "poster";
    $("posterExport").hidden = state.type !== "poster";
    $("posterOrderNote").hidden = true;
    if (state.type === "poster") {
      $("designExportTitle").textContent = "Exporter l’affiche";
      $("designExportHelp").textContent = "Télécharge l’affiche en haute définition : PNG (réseaux sociaux) ou PDF (impression).";
      $("exportPosterPng").hidden = false;
    } else if (state.type === "cv") {
      $("posterOrderNote").hidden = false;
      $("posterOrderNote").querySelector("h3").textContent = "Ton CV est prêt à être finalisé";
      $("posterOrderNote").querySelector("p").textContent = "Tu peux créer et modifier ton design dans le Studio. Le téléchargement du fichier final est réservé aux commandes payantes auprès de Stromtech.";
    }
    root.textContent = "";
    var dark = state.theme === "dark";
    root.style.setProperty("--pc", state.color);
    root.style.setProperty("--pbg", dark ? "#12141c" : "#ffffff");
    root.style.setProperty("--ptx", dark ? "#f2f4ff" : "#14161f");
    root.style.setProperty("--ppn", dark ? "#1e2230" : "#f4f6fb");
    root.style.setProperty("--pr", RADII[state.radius][1]);
    root.style.setProperty("--pf", FONTS[state.font][1]);
    root.style.setProperty("--poster-accent", state.color);
    $("frame").className = "frame is-" + state.type;
    $("frame").dataset.viewport = viewport;
    document.querySelectorAll("[data-viewport]").forEach(function (b) {
      b.setAttribute("aria-pressed", String(b.getAttribute("data-viewport") === viewport));
    });
    var label = $("viewLabel");
    if (label) label.textContent = ({app:"Aperçu de l’application · mobile",cv:"Création de CV · aperçu A4",poster:"Création d’affiche · " + ({portrait:"portrait",square:"carré",story:"story",landscape:"paysage",a4:"A4"}[state.posterFormat] || "portrait"),site:"Aperçu du site · " + (viewport === "desktop" ? "ordinateur" : viewport === "tablet" ? "tablette" : "mobile")})[state.type];
    document.querySelectorAll(".viewport-switch button").forEach(function (b) {
      b.hidden = state.type !== "site" && b.getAttribute("data-viewport") !== "mobile";
    });
    if (state.type === "site") previewSite(root); else if (state.type === "app") previewApp(root); else if (state.type === "cv") previewCV(root); else previewPoster(root);
    if (state.type === "poster") {
      var posterNode = root.querySelector(".pv-poster");
      if (posterNode) {
        var formats = { portrait: { width: 560, height: 700 }, square: { width: 560, height: 560 }, story: { width: 420, height: 746 }, landscape: { width: 760, height: 428 }, a4: { width: 560, height: 792 } };
        var posterSize = formats[state.posterFormat] || formats.portrait;
        posterNode.style.width = "min(100%, " + posterSize.width + "px)";
        posterNode.style.minHeight = posterSize.height + "px";
        posterNode.style.height = posterSize.height + "px";
      }
    }
    if (selectedKey) { var selected = root.querySelector('[data-editable="' + selectedKey + '"]'); if (selected) selected.classList.add("is-selected"); }
    updateInspector();
    renderLayers();
  }

  function renderLayers() {
    var host = $("studioLayers"); if (!host || state.type === "poster") return;
    host.textContent = "";
    if (!state.blocks.length) { var empty = el("p", "identity-help", "Aucun élément ajouté pour le moment."); host.appendChild(empty); return; }
    state.blocks.forEach(function (block, index) {
      var row = el("div", "studio-layer-row" + (block.id === selectedKey ? " is-active" : ""));
      var select = el("button", "studio-layer-select", block.type === "image" ? "▧ Image" : block.type === "shape" ? "▰ Forme" : block.type === "button" ? "▣ Bouton" : "T  " + ((state.content[block.id] || "Texte").slice(0, 18)));
      select.type = "button"; select.addEventListener("click", function () { selectedKey = block.id; render(); }); row.appendChild(select);
      var up = el("button", "studio-layer-move", "↑"); up.type = "button"; up.title = "Avancer le calque"; up.disabled = index === state.blocks.length - 1; up.addEventListener("click", function () { var a = state.blocks[index]; state.blocks[index] = state.blocks[index + 1]; state.blocks[index + 1] = a; render(); saveDraft(); }); row.appendChild(up);
      var down = el("button", "studio-layer-move", "↓"); down.type = "button"; down.title = "Reculer le calque"; down.disabled = index === 0; down.addEventListener("click", function () { var a = state.blocks[index]; state.blocks[index] = state.blocks[index - 1]; state.blocks[index - 1] = a; render(); saveDraft(); }); row.appendChild(down);
      var duplicate = el("button", "studio-layer-move", "＋"); duplicate.type = "button"; duplicate.title = "Dupliquer cet élément"; duplicate.addEventListener("click", function () { duplicateBlock(block.id); }); row.appendChild(duplicate);
      host.appendChild(row);
    });
  }

  function duplicateBlock(id) {
    if (state.blocks.length >= 30) { showMsg($("warn"), "Limite de 30 éléments atteinte.", true); return; }
    var source = state.blocks.find(function (b) { return b.id === id; }); if (!source) return;
    var nextId = "block_" + Date.now(); while (state.blocks.some(function (b) { return b.id === nextId; })) nextId = "block_" + (Number(nextId.slice(6)) + 1);
    var copy = { id: nextId, type: source.type }; state.blocks.splice(state.blocks.indexOf(source) + 1, 0, copy);
    ["content","elementColors","blockOffsets","blockPositions","blockSizes","blockStyles","imageStyles","imageData","imageWidths"].forEach(function (group) {
      var value = state[group] && state[group][id]; if (value !== undefined) state[group][nextId] = value && typeof value === "object" ? JSON.parse(JSON.stringify(value)) : value;
    });
    if (source.type === "image" && Object.keys(state.imageData).length > 3) { delete state.imageData[nextId]; state.blocks = state.blocks.filter(function (b) { return b.id !== nextId; }); showMsg($("warn"), "La limite de trois images est atteinte.", true); return; }
    selectedKey = nextId; render(); saveDraft();
  }

  /* ---------- Commandes ---------- */
  function seg(host, items, current, onPick) {
    host.textContent = "";
    items.forEach(function (it) { var b = el("button", "", it[1]); b.type = "button"; b.setAttribute("aria-pressed", String(it[0] === current)); b.addEventListener("click", function () { onPick(it[0]); }); host.appendChild(b); });
  }
  function buildControls() {
    seg($("typeSeg"), [["site", "Site Web"], ["app", "Application mobile"], ["cv", "CV professionnel"], ["poster", "Affiche"]], state.type, function (v) { if (v !== state.type) { state = Object.assign(defaults(v), { name: state.name, brandMode: state.brandMode, brandLogo: state.brandLogo, brandLogoWidth: state.brandLogoWidth, brandLogoBorder: state.brandLogoBorder, brandLogoBorderColor: state.brandLogoBorderColor, brandLogoBorderWidth: state.brandLogoBorderWidth, slogan: state.slogan, color: state.color, font: state.font, radius: state.radius, theme: state.theme, notes: state.notes }); change(true); } });
    var tl = $("tplList"); tl.textContent = "";
    (state.type === "poster" ? [] : Object.keys(TPL[state.type])).forEach(function (k) {
      var t = TPL[state.type][k], b = el("button", "tpl"); b.type = "button"; b.setAttribute("aria-pressed", String(k === state.template));
      var visual = el("span", "tpl-preview tpl-preview-" + k); if (t.preset) { visual.style.setProperty("--tc", t.preset.color); if (t.preset.theme === "dark") visual.classList.add("tpl-dark"); }
      visual.appendChild(el("i", "tpl-preview-top")); visual.appendChild(el("i", "tpl-preview-hero")); visual.appendChild(el("i", "tpl-preview-content"));
      b.appendChild(visual);
      b.appendChild(el("b", "", t.label)); b.appendChild(el("span", "tpl-tag", t.tag || ({site:"Site Web",app:"Application",cv:"CV",poster:"Affiche"}[state.type])));
      b.appendChild(el("span", "", t.desc));
      b.addEventListener("click", function () { var prevT = TPL[state.type][state.template]; state.template = k; state.sections = t.sections.slice(); if (state.type === "poster") state.canvas = null; else applyTemplatePreset(prevT, t); change(true); }); tl.appendChild(b);
    });
    if (state.type === "poster") window.PosterCanvas.gallery(tl, state, function (k) {
      if (k === state.template && state.canvas) return;
      if (state.canvas && state.canvas.els.length && !window.confirm("Remplacer ta création actuelle par ce modèle ?")) return;
      state.template = k; state.sections = TPL.poster[k].sections.slice(); state.canvas = null; change(true);
    });
    var sw = $("swatches"); sw.textContent = "";
    COLORS.forEach(function (c) { var b = el("button", "sw"); b.type = "button"; b.style.background = c[1]; b.title = c[0]; b.setAttribute("aria-label", c[0]); b.setAttribute("aria-pressed", String(state.color.toLowerCase() === c[1])); b.addEventListener("click", function () { state.color = c[1]; change(true); }); sw.appendChild(b); });
    $("color").value = state.color;
    seg($("themeSeg"), [["light", "Clair"], ["dark", "Sombre"]], state.theme, function (v) { state.theme = v; change(true); });
    seg($("radiusSeg"), Object.keys(RADII).map(function (k) { return [k, RADII[k][0]]; }), state.radius, function (v) { state.radius = v; change(true); });
    $("font").value = state.font;
    $("posterOptions").hidden = state.type !== "poster";
    $("posterFormat").value = state.posterFormat;
    $("posterVisualHeight").value = state.posterVisualHeight;
    $("posterVisualHeightValue").textContent = state.posterVisualHeight + " px";
    $("posterImageFit").value = state.posterImageFit;
    $("name").value = state.name; $("slogan").value = state.slogan; $("notes").value = state.notes;
    $("brandNameField").hidden = state.brandMode === "logo";
    $("brandLogoField").hidden = state.brandMode !== "logo";
    $("brandNameMode").setAttribute("aria-pressed", String(state.brandMode === "name"));
    $("brandLogoMode").setAttribute("aria-pressed", String(state.brandMode === "logo"));
    $("brandLogoStatus").textContent = state.brandLogo ? "Logo ajouté à l’aperçu." : "PNG, JPG ou WebP · 5 Mo maximum";
    $("removeBrandLogo").hidden = !state.brandLogo;
    $("brandLogoWidth").value = state.brandLogoWidth; $("brandLogoWidthValue").textContent = state.brandLogoWidth + " px";
    $("brandLogoBorder").checked = state.brandLogoBorder; $("brandLogoBorderOptions").hidden = !state.brandLogoBorder;
    $("brandLogoBorderColor").value = state.brandLogoBorderColor; $("brandLogoBorderWidth").value = state.brandLogoBorderWidth; $("brandLogoBorderWidthValue").textContent = state.brandLogoBorderWidth + " px";
    renderPages();
    $("secLegend").textContent = state.type === "site" ? "Sections de ta page" : state.type === "app" ? "Écrans de ton application (5 maximum)" : state.type === "cv" ? "Rubriques du CV" : "Éléments de l’affiche";
    var sectionGroup = $("secLegend").parentElement; sectionGroup.hidden = state.type === "cv" || state.type === "poster";
    var pageGroup = document.querySelector(".page-manager"); if (pageGroup) pageGroup.hidden = state.type === "cv" || state.type === "poster";
    var sl = $("secList"); sl.textContent = ""; var max = state.type === "app" ? 5 : 7, full = state.sections.length >= max;
    Object.keys(SEC[state.type]).forEach(function (k) {
      var on = state.sections.indexOf(k) >= 0, lab = el("label", "chk"), cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = on;
      cb.disabled = (!on && full) || (state.type === "app" && k === "accueil");
      cb.addEventListener("change", function () { state.sections = Object.keys(SEC[state.type]).filter(function (x) { return x === k ? cb.checked : state.sections.indexOf(x) >= 0; }); change(true); });
      lab.appendChild(cb); lab.appendChild(document.createTextNode(" " + SEC[state.type][k])); sl.appendChild(lab);
      if (state.type === "site" && (k === "galerie" || k === "produits") && on) {
        var tools = el("div", "section-image-tools");
        var settings = state.sectionImageSettings[k];
        var fitLabel = el("label", "section-image-setting-label", "Affichage");
        var fitSelect = document.createElement("select"); fitSelect.className = "section-image-fit";
        [["cover","Remplir le cadre"],["contain","Afficher toute l’image"]].forEach(function (opt) { var option=document.createElement("option"); option.value=opt[0]; option.textContent=opt[1]; fitSelect.appendChild(option); });
        fitSelect.value=settings.fit; fitSelect.addEventListener("change", function () { settings.fit=this.value; render(); saveDraft(); });
        var heightLabel=el("label","section-image-setting-label","Hauteur : "); var heightValue=el("b","section-image-height-value",settings.height+" px"); heightLabel.appendChild(heightValue);
        var heightRange=document.createElement("input"); heightRange.type="range"; heightRange.min="80"; heightRange.max="260"; heightRange.step="5"; heightRange.value=settings.height; heightRange.className="section-image-height";
        heightRange.addEventListener("input",function(){settings.height=Number(this.value);heightValue.textContent=settings.height+" px";applySectionImageSizing(k);saveDraft();});
        tools.appendChild(fitLabel); tools.appendChild(fitSelect); tools.appendChild(heightLabel); tools.appendChild(heightRange);
        var count = (state.sectionImages[k] || []).length;
        var choose = el("button", "section-image-pick", k === "galerie" ? "＋ Ajouter des photos" : "＋ Ajouter des images de produits"); choose.type = "button"; choose.disabled = count >= 8;
        var input = document.createElement("input"); input.type = "file"; input.accept = "image/png,image/jpeg,image/webp"; input.multiple = true; input.hidden = true;
        choose.addEventListener("click", function () { input.click(); });
        input.addEventListener("change", function () { addSectionImages(k, input.files); input.value = ""; });
        if(k==="produits") {
          var productEditor=el("div","product-details-editor"); productEditor.appendChild(el("h4","","Informations des produits"));
          for(var pi=0;pi<Math.max(4,count);pi++) { (function(index){ var detail=state.productDetails[index]||{name:"",price:"",description:""}; var card=el("div","product-detail-fields"); card.appendChild(el("b","","Produit "+(index+1)));
            [["name","Nom du produit","text"],["price","Prix (ex. 12 500 FCFA)","text"],["description","Description courte","text"]].forEach(function(field){var inputField=document.createElement("input");inputField.type="text";inputField.maxLength=field[0]==="description"?140:field[0]==="name"?60:30;inputField.placeholder=field[1];inputField.value=detail[field[0]]||"";inputField.setAttribute("aria-label",field[1]+" produit "+(index+1));inputField.addEventListener("input",function(){if(!state.productDetails[index])state.productDetails[index]={name:"",price:"",description:""};state.productDetails[index][field[0]]=this.value;render();saveDraft();});card.appendChild(inputField);}); productEditor.appendChild(card); })(pi); }
          tools.appendChild(productEditor);
        }
        tools.appendChild(choose); tools.appendChild(el("span", "section-image-count", count + "/8 images"));
        if (count) {
          var imageList = el("div", "section-image-list");
          state.sectionImages[k].forEach(function (src, index) {
            var row = el("div", "section-image-row");
            var thumb = el("img", "section-image-thumb"); thumb.src = src; thumb.alt = (k === "galerie" ? "Photo " : "Produit ") + (index + 1); row.appendChild(thumb);
            row.appendChild(el("span", "section-image-row-name", (k === "galerie" ? "Photo " : "Image produit ") + (index + 1)));
            var up = el("button", "section-image-order", "↑"); up.type = "button"; up.disabled = index === 0; up.title = "Monter";
            up.addEventListener("click", function () { moveSectionImage(k, index, -1); }); row.appendChild(up);
            var down = el("button", "section-image-order", "↓"); down.type = "button"; down.disabled = index === count - 1; down.title = "Descendre";
            down.addEventListener("click", function () { moveSectionImage(k, index, 1); }); row.appendChild(down);
            var remove = el("button", "section-image-remove", "Retirer"); remove.type = "button"; remove.addEventListener("click", function () { state.sectionImages[k].splice(index, 1); change(true); }); row.appendChild(remove);
            imageList.appendChild(row);
          });
          tools.appendChild(imageList);
          var clear = el("button", "section-image-clear", "Tout retirer"); clear.type = "button"; clear.addEventListener("click", function () { state.sectionImages[k] = []; change(true); }); tools.appendChild(clear);
        }
        tools.appendChild(input); sl.appendChild(tools);
      }
      if (state.type === "site" && k === "contact" && on) {
        var contactEditor=el("div","custom-cards-editor");
        contactEditor.appendChild(el("h4","","Personnaliser le formulaire"));
        [["nameLabel","Champ Nom",60],["firstNameLabel","Champ Prénom",60],["phoneLabel","Champ Téléphone",60],["emailLabel","Champ E-mail",60],["buttonLabel","Texte du bouton",40]].forEach(function(field){
          var inputField=document.createElement("input");inputField.type="text";inputField.maxLength=field[2];inputField.placeholder=field[1];inputField.value=state.contactDetails[field[0]]||"";inputField.setAttribute("aria-label",field[1]);
          inputField.addEventListener("change",function(){state.contactDetails[field[0]]=this.value;render();saveDraft();});
          contactEditor.appendChild(inputField);
        });
        sl.appendChild(contactEditor);
      }
      if (state.type === "site" && k === "temoignages" && on) {
        var testimonialEditor = el("div", "custom-cards-editor");
        testimonialEditor.appendChild(el("h4", "", "Personnaliser les témoignages"));
        for (var ti=0;ti<Math.max(2,state.testimonialDetails.length);ti++) {
          (function(index) {
            var detail=state.testimonialDetails[index]||{}, card=el("div","custom-card-fields");
            card.appendChild(el("b","","Témoignage "+(index+1)));
            [["quote","Avis du client",240],["author","Nom du client",60]].forEach(function(field) {
              var inputField=document.createElement("input");inputField.type="text";inputField.maxLength=field[2];inputField.placeholder=field[1];inputField.value=detail[field[0]]||"";
              inputField.setAttribute("aria-label",field[1]+" "+(index+1));
              inputField.addEventListener("change",function(){if(!state.testimonialDetails[index])state.testimonialDetails[index]={quote:"",author:""};state.testimonialDetails[index][field[0]]=this.value;render();saveDraft();});
              card.appendChild(inputField);
            });
            testimonialEditor.appendChild(card);
          })(ti);
        }
        var addTestimonial=el("button","custom-card-add","＋ Ajouter un témoignage");addTestimonial.type="button";addTestimonial.disabled=state.testimonialDetails.length>=6;
        addTestimonial.addEventListener("click",function(){if(state.testimonialDetails.length<6){state.testimonialDetails.push({quote:"",author:""});change(true);}});
        testimonialEditor.appendChild(addTestimonial);
        if(state.testimonialDetails.length>2){var removeTestimonial=el("button","custom-card-remove","Retirer le dernier témoignage");removeTestimonial.type="button";removeTestimonial.addEventListener("click",function(){state.testimonialDetails.pop();change(true);});testimonialEditor.appendChild(removeTestimonial);}
        sl.appendChild(testimonialEditor);
      }
      if (state.type === "site" && (k === "services" || k === "tarifs") && on) {
        var isServices = k === "services", collection = isServices ? state.serviceDetails : state.pricingDetails;
        var editor = el("div", "custom-cards-editor");
        editor.appendChild(el("h4", "", isServices ? "Personnaliser les services" : "Personnaliser les tarifs"));
        var cardLimit = isServices ? 6 : 6, cardMinimum = 3;
        for (var ci=0; ci<Math.max(cardMinimum, collection.length); ci++) {
          (function(index) {
            var detail = collection[index] || {};
            var card = el("div", "custom-card-fields");
            card.appendChild(el("b", "", (isServices ? "Service " : "Offre ") + (index+1)));
            var fields = isServices ? [["name","Nom du service",60],["description","Description du service",140]] : [["name","Nom de l’offre",60],["price","Prix (ex. 15 000 FCFA)",30],["description","Description de l’offre",140]];
            fields.forEach(function(field) {
              var inputField = document.createElement("input");
              inputField.type = "text"; inputField.maxLength = field[2]; inputField.placeholder = field[1];
              inputField.value = detail[field[0]] || "";
              inputField.setAttribute("aria-label", field[1] + " " + (index+1));
              inputField.addEventListener("input", function() {
                var targetCollection = k === "services" ? state.serviceDetails : state.pricingDetails;
                if (!targetCollection[index]) targetCollection[index] = {name:"",price:"",description:""};
                targetCollection[index][field[0]] = this.value;
                render(); saveDraft();
              });
              card.appendChild(inputField);
            });
            editor.appendChild(card);
          })(ci);
        }
        var addCard = el("button", "custom-card-add", "＋ Ajouter " + (isServices ? "un service" : "une offre"));
        addCard.type = "button"; addCard.disabled = collection.length >= cardLimit;
        addCard.addEventListener("click", function() {
          var targetCollection = k === "services" ? state.serviceDetails : state.pricingDetails;
          if (targetCollection.length >= cardLimit) return;
          targetCollection.push({name:"",price:"",description:""});
          change(true);
        });
        editor.appendChild(addCard);
        if (collection.length > cardMinimum) {
          var removeCard = el("button", "custom-card-remove", "Retirer le dernier " + (isServices ? "service" : "forfait"));
          removeCard.type = "button";
          removeCard.addEventListener("click", function(){var targetCollection = k === "services" ? state.serviceDetails : state.pricingDetails;targetCollection.pop();change(true);});
          editor.appendChild(removeCard);
        }
        sl.appendChild(editor);
      }
    });
  }

  function change(rebuild) { if (rebuild) buildControls(); render(); saveDraft(); }


  function setStudioWorkspace(type) {
    var info = {
      site: { eyebrow: "WEB DESIGN STUDIO", title: "Atelier Sites Web", description: "Compose des pages web, organise tes sections et adapte le rendu aux écrans ordinateur, tablette et mobile.", templates: "Modèles de sites Web", help: "Choisis une structure adaptée : vitrine, portfolio, boutique, page de conversion ou événement." },
      app: { eyebrow: "MOBILE APP STUDIO", title: "Atelier Applications mobiles", description: "Imagine les écrans de ton application, son parcours et ses principales fonctionnalités.", templates: "Modèles d’applications", help: "Démarre avec une base Commandes, Rendez-vous, Gestion, Livraison ou Éducation." },
      cv: { eyebrow: "CV DESIGN STUDIO", title: "Atelier CV professionnels", description: "Construis un CV clair et soigné, rubrique par rubrique, avec un aperçu de document.", templates: "Modèles de CV", help: "Compare les présentations Classique, Moderne et Minimaliste avant de personnaliser ton contenu." },
      poster: { eyebrow: "GRAPHIC DESIGN STUDIO", title: "Atelier Affiches et visuels", description: "Crée une composition visuelle, choisis son format et organise titres, images et informations.", templates: "Modèles d’affiches", help: "Choisis un modèle par catégorie (fêtes, mariage, soirée, commerce, beauté, restauration…). Tout est modifiable : textes, couleurs, cadres photo." }
    };
    var data = info[type] || info.site;
    $("studioWorkspaceEyebrow").textContent = data.eyebrow;
    $("studioWorkspaceTitle").textContent = data.title;
    $("studioWorkspaceDescription").textContent = data.description;
    $("studioTemplateHeading").textContent = data.templates;
    $("studioTemplateHelp").textContent = data.help;
    $("studioWorkspace").hidden = false;
    document.body.setAttribute("data-studio-service", type);
  }

  function openStudioService(type) {
    if (["site","app","cv","poster"].indexOf(type) < 0) return;
    var saved = loadDraft(type);
    state = clean(saved || defaults(type));
    pages = []; activePageId = null; selectedKey = null;
    initPages(saved);
    $("studioServiceHub").hidden = true;
    $("controls").hidden = false;
    $("studioBackHub").hidden = false;
    setStudioWorkspace(type);
    buildControls(); render(); renderPages(); saveDraft();
    window.scrollTo({top:0,behavior:"smooth"});
  }
  function showStudioHub() {
    saveDraft();
    $("controls").hidden = true;
    $("studioServiceHub").hidden = false;
    $("studioBackHub").hidden = true;
    $("studioWorkspace").hidden = true;
    document.body.removeAttribute("data-studio-service");
    window.scrollTo({top:0,behavior:"smooth"});
  }
  function bind() {
    bindBlockDragging();
    $("addPage").addEventListener("click", function () { createPage(false); });
    $("renamePage").addEventListener("click", renameCurrentPage);
    $("duplicatePage").addEventListener("click", function () { createPage(true); });
    $("deletePage").addEventListener("click", deleteCurrentPage);
    $("pv").addEventListener("click", function (event) {
      var target = event.target.closest("[data-editable]");
      if (!target) return;
      event.preventDefault();
      selectedKey = target.dataset.editable;
      render();
    });
    $("elementText").addEventListener("input", function () {
      if (!selectedKey) return;
      state.content[selectedKey] = $("elementText").value.slice(0, 200);
      render(); saveDraft();
    });
    function updateSelectedBlockStyle(key, property, value) {
      if (!key || !state.blocks.some(function (b) { return b.id === key; })) return;
      state.blockStyles[key] = state.blockStyles[key] || {};
      state.blockStyles[key][property] = value;
      render(); saveDraft();
    }
    function updateSelectedImageStyle(property, value) {
      if (!selectedKey || !state.blocks.some(function (b) { return b.id === selectedKey && b.type === "image"; })) return;
      state.imageStyles[selectedKey] = state.imageStyles[selectedKey] || {};
      state.imageStyles[selectedKey][property] = value;
      render(); saveDraft();
    }
    function updateSelectedBlockPosition(axis, value) {
      if (!selectedKey || !state.blocks.some(function (b) { return b.id === selectedKey; })) return;
      var position = state.blockPositions[selectedKey] || { x: 0, y: 0 };
      position[axis] = Math.max(-1200, Math.min(1200, Number(value)));
      state.blockPositions[selectedKey] = position;
      var item = $("pv").querySelector('[data-block-id="' + selectedKey + '"]');
      if (item) { var offset = state.blockOffsets[selectedKey] || 0; item.style.transform = "translate3d(" + (position.x + offset) + "px," + position.y + "px,0)"; }
      $("blockPosition" + axis.toUpperCase() + "Value").textContent = position[axis] + " px";
      saveDraft();
    }
    function alignSelectedBlock(alignment) {
      if (!selectedKey || !state.blocks.some(function (b) { return b.id === selectedKey; })) return;
      var item = $("pv").querySelector('[data-block-id="' + selectedKey + '"]');
      var wrap = item && item.parentElement;
      if (!item || !wrap) return;
      var itemWidth = item.getBoundingClientRect().width;
      var available = Math.max(0, wrap.clientWidth - 44);
      var x = alignment === "center" ? Math.round((available - itemWidth) / 2) : alignment === "right" ? Math.round(available - itemWidth) : 0;
      state.blockPositions[selectedKey] = { x: x, y: (state.blockPositions[selectedKey] || { y: 0 }).y };
      var y = state.blockPositions[selectedKey].y;
      item.style.transform = "translate3d(" + x + "px," + y + "px,0)";
      $("blockPositionX").value = Math.max(-500, Math.min(500, x));
      $("blockPositionXValue").textContent = x + " px";
      saveDraft();
    }
    $("alignBlockLeft").addEventListener("click", function () { alignSelectedBlock("left"); });
    $("alignBlockCenter").addEventListener("click", function () { alignSelectedBlock("center"); });
    $("alignBlockRight").addEventListener("click", function () { alignSelectedBlock("right"); });
    $("blockPositionX").addEventListener("input", function () { updateSelectedBlockPosition("x", this.value); });
    $("blockPositionY").addEventListener("input", function () { updateSelectedBlockPosition("y", this.value); });
    $("resetBlockPosition").addEventListener("click", function () {
      if (!selectedKey || !state.blocks.some(function (b) { return b.id === selectedKey; })) return;
      state.blockPositions[selectedKey] = { x: 0, y: 0 };
      var item = $("pv").querySelector('[data-block-id="' + selectedKey + '"]');
      if (item) item.style.transform = "translate3d(0px,0px,0)";
      $("blockPositionX").value = 0; $("blockPositionY").value = 0;
      $("blockPositionXValue").textContent = "0 px"; $("blockPositionYValue").textContent = "0 px";
      saveDraft();
    });
    $("imageFit").addEventListener("change", function () { updateSelectedImageStyle("fit", this.value); });
    $("imageRadius").addEventListener("input", function () { $("imageRadiusValue").textContent = this.value + " px"; updateSelectedImageStyle("radius", Number(this.value)); });
    $("imageBorder").addEventListener("change", function () { $("imageBorderColor").disabled = !this.checked; updateSelectedImageStyle("border", this.checked); });
    $("imageBorderColor").addEventListener("input", function () { updateSelectedImageStyle("borderColor", this.value); });
    $("blockFontSize").addEventListener("input", function () { $("blockFontSizeValue").textContent = this.value + " px"; updateSelectedBlockStyle(selectedKey, "fontSize", Number(this.value)); });
    $("blockTextAlign").addEventListener("change", function () { updateSelectedBlockStyle(selectedKey, "textAlign", this.value); });
    $("blockFontWeight").addEventListener("change", function () { updateSelectedBlockStyle(selectedKey, "fontWeight", this.value); });
    $("blockFontFamily").addEventListener("change", function () { updateSelectedBlockStyle(selectedKey, "fontFamily", this.value); });
    $("blockItalic").addEventListener("change", function () { updateSelectedBlockStyle(selectedKey, "italic", this.checked); });
    $("blockUnderline").addEventListener("change", function () { updateSelectedBlockStyle(selectedKey, "underline", this.checked); });
    $("blockLetterSpacing").addEventListener("input", function () { $("blockLetterSpacingValue").textContent = this.value + " px"; updateSelectedBlockStyle(selectedKey, "letterSpacing", Number(this.value)); });
    $("blockLineHeight").addEventListener("input", function () { $("blockLineHeightValue").textContent = Number(this.value).toFixed(1); updateSelectedBlockStyle(selectedKey, "lineHeight", Number(this.value)); });
    $("blockBackground").addEventListener("input", function () { updateSelectedBlockStyle(selectedKey, "backgroundColor", this.value); });
    $("blockRadius").addEventListener("input", function () { $("blockRadiusValue").textContent = this.value + " px"; updateSelectedBlockStyle(selectedKey, "radius", Number(this.value)); });
    $("elementColor").addEventListener("input", function () {
      if (!selectedKey) return;
      state.elementColors[selectedKey] = $("elementColor").value;
      render(); saveDraft();
    });
    $("clearSelection").addEventListener("click", function () { selectedKey = null; render(); });
    $("addTextBlock").addEventListener("click", function () { addBlock("text"); });
    $("addButtonBlock").addEventListener("click", function () { addBlock("button"); });
    $("addImageBlock").addEventListener("click", function () { $("imageUpload").click(); });
    $("addShapeBlock").addEventListener("click", function () { addBlock("shape"); });
    $("brandNameMode").addEventListener("click", function () { state.brandMode = "name"; change(true); });
    $("brandLogoMode").addEventListener("click", function () { state.brandMode = "logo"; buildControls(); render(); saveDraft(); if (!state.brandLogo) $("brandLogoUpload").click(); });
    $("chooseBrandLogo").addEventListener("click", function () { $("brandLogoUpload").click(); });
    $("brandLogoUpload").addEventListener("change", function () { if (this.files && this.files[0]) addBrandLogo(this.files[0]); this.value = ""; });
    $("removeBrandLogo").addEventListener("click", function () { state.brandLogo = ""; state.brandMode = "name"; change(true); });
    $("brandLogoWidth").addEventListener("input", function () { state.brandLogoWidth = Number(this.value); $("brandLogoWidthValue").textContent = this.value + " px"; render(); saveDraft(); });
    $("brandLogoBorder").addEventListener("change", function () { state.brandLogoBorder = this.checked; $("brandLogoBorderOptions").hidden = !this.checked; render(); saveDraft(); });
    $("brandLogoBorderColor").addEventListener("input", function () { state.brandLogoBorderColor = this.value; render(); saveDraft(); });
    $("brandLogoBorderWidth").addEventListener("input", function () { state.brandLogoBorderWidth = Number(this.value); $("brandLogoBorderWidthValue").textContent = this.value + " px"; render(); saveDraft(); });
    $("imageUpload").addEventListener("change", function () { if (this.files && this.files[0]) addImage(this.files[0]); this.value = ""; });
    $("imageWidth").addEventListener("input", function () {
      if (!selectedKey) return;
      state.imageWidths[selectedKey] = Number(this.value);
      var img = $("pv").querySelector('[data-block-id="' + selectedKey + '"]');
      if (img) { img.style.width = this.value + "%"; img.style.height = ""; var innerImage = img.querySelector("img"); if (innerImage) { innerImage.style.width = "100%"; innerImage.style.height = "auto"; } }
      delete state.blockSizes[selectedKey];
      saveDraft();
    });
    $("deleteBlock").addEventListener("click", deleteSelectedBlock);
    document.querySelectorAll("[data-viewport]").forEach(function (b) {
      b.addEventListener("click", function () {
        viewport = b.getAttribute("data-viewport");
        render();
      });
    });
    $("font").addEventListener("change", function () { state.font = $("font").value; change(false); });
    $("posterFormat").addEventListener("change", function () { state.posterFormat = this.value; render(); saveDraft(); });
    $("posterVisualHeight").addEventListener("input", function () { state.posterVisualHeight = Number(this.value); $("posterVisualHeightValue").textContent = this.value + " px"; render(); saveDraft(); });
    $("posterImageFit").addEventListener("change", function () { state.posterImageFit = this.value; render(); saveDraft(); });
    $("color").addEventListener("input", function () { state.color = $("color").value; change(false); });
    $("color").addEventListener("change", function () { buildControls(); });
    ["name", "slogan", "notes"].forEach(function (id) { $(id).addEventListener("input", function () { state[id] = $(id).value; change(false); }); });
    $("reset").addEventListener("click", function () {
      var currentType = state.type;
      var blankTemplate = currentType === "site" || currentType === "poster" ? "blank" : undefined;
      state = defaults(currentType, blankTemplate);
      pages = [];
      activePageId = null;
      selectedKey = null;
      initPages(null);
      buildControls();
      render();
      renderPages();
      saveDraft();
      showMsg($("warn"), "");
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
    $("sendBtn").addEventListener("click", send);
    $("exportPosterPng").addEventListener("click", function () { exportPoster("png"); });
    $("exportPosterPdf").addEventListener("click", function () { exportPoster("pdf"); });
  }

  async function exportPoster(format) {
    if (state.type === "cv") { $("exportStatus").textContent = "Le téléchargement du fichier final est réservé aux commandes payantes Stromtech."; return; }
    if (state.type === "poster" && state.canvas && window.PosterCanvas && window.PosterCanvas.toCanvas) {
      var st = $("exportStatus"), b1 = $("exportPosterPng"), b2 = $("exportPosterPdf");
      if (format === "pdf" && !(window.jspdf && window.jspdf.jsPDF)) { st.textContent = "Le module PDF n’a pas pu se charger. Vérifie ta connexion puis recharge la page."; return; }
      b1.disabled = true; b2.disabled = true; st.textContent = "Préparation du fichier…";
      try {
        var cv = await window.PosterCanvas.toCanvas(state, Math.min(3, 4200 / Math.max(state.canvas.W, state.canvas.H)));
        var fn = (state.name || "stromtech-affiche").toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-|-$/g, "") || "stromtech-affiche";
        if (format === "png") { var a = document.createElement("a"); a.download = fn + ".png"; a.href = cv.toDataURL("image/png"); a.click(); }
        else {
          var wmm = state.canvas.W >= state.canvas.H ? 297 : 210, hmm = wmm * cv.height / cv.width;
          var pd = new window.jspdf.jsPDF({ orientation: hmm > wmm ? "portrait" : "landscape", unit: "mm", format: [wmm, hmm], compress: true });
          pd.addImage(cv.toDataURL("image/jpeg", 0.95), "JPEG", 0, 0, wmm, hmm, undefined, "FAST"); pd.save(fn + ".pdf");
        }
        st.textContent = format === "png" ? "Image PNG téléchargée." : "PDF téléchargé.";
      } catch (err) { console.error("Export affiche :", err); st.textContent = "L’export a échoué (image externe bloquée ?). Réessaie."; }
      finally { b1.disabled = false; b2.disabled = false; }
      return;
    }
    var poster = $("pv").querySelector(state.type === "cv" ? ".pv-cv" : ".pv-poster");
    var status = $("exportStatus"), pngBtn = $("exportPosterPng"), pdfBtn = $("exportPosterPdf");
    if (!poster) { status.textContent = "Sélectionne d’abord le type Affiche."; return; }
    if (typeof window.html2canvas !== "function") { status.textContent = "Le module d’export n’a pas pu se charger. Vérifie ta connexion puis recharge la page."; return; }
    if (format === "pdf" && !(window.jspdf && window.jspdf.jsPDF)) { status.textContent = "Le module PDF n’a pas pu se charger. Vérifie ta connexion puis recharge la page."; return; }
    pngBtn.disabled = true; pdfBtn.disabled = true; status.textContent = "Préparation du fichier…";
    try {
      await document.fonts.ready;
      var canvas = await window.html2canvas(poster, {
        scale: 3, backgroundColor: "#ffffff", useCORS: true,
        logging: false, scrollX: 0, scrollY: 0,
        onclone: function (doc) {
          doc.querySelectorAll(".is-selected,.is-dragging,.is-resizing").forEach(function (node) {
            node.classList.remove("is-selected", "is-dragging", "is-resizing");
          });
          doc.querySelectorAll(".pv-resize-handle").forEach(function (node) { node.remove(); });
        }
      });
      var baseName = state.type === "cv" ? (state.name || "stromtech-cv") : (state.name || "stromtech-affiche");
      var filename = baseName.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-|-$/g, "") || "stromtech-affiche";
      if (format === "png") {
        var link = document.createElement("a");
        link.download = filename + ".png"; link.href = canvas.toDataURL("image/png"); link.click();
      } else {
        var JsPDF = window.jspdf.jsPDF;
        var pdf;
        if (state.type === "cv") {
          pdf = new JsPDF({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
          var pageWidth = 210, pageHeight = 297, margin = 8;
          var ratio = Math.min((pageWidth - margin * 2) / canvas.width, (pageHeight - margin * 2) / canvas.height);
          var imageWidth = canvas.width * ratio, imageHeight = canvas.height * ratio;
          pdf.addImage(canvas.toDataURL("image/jpeg", 0.96), "JPEG",
            (pageWidth - imageWidth) / 2, (pageHeight - imageHeight) / 2,
            imageWidth, imageHeight, undefined, "FAST");
        } else {
          var width = 210, height = width * canvas.height / canvas.width;
          pdf = new JsPDF({ orientation: height > width ? "portrait" : "landscape", unit: "mm", format: [width, height], compress: true });
          pdf.addImage(canvas.toDataURL("image/jpeg", 0.96), "JPEG", 0, 0, width, height, undefined, "FAST");
        }
        pdf.save(filename + ".pdf");
      }
      status.textContent = format === "png" ? "Image PNG téléchargée." : "PDF prêt à imprimer téléchargé.";
    } catch (error) {
      console.error("Export affiche Stromtech :", error);
      status.textContent = "L’export a échoué. Essaie avec une image plus légère ou recharge le Studio.";
    } finally { pngBtn.disabled = false; pdfBtn.disabled = false; }
  }

  function addBlock(type) {
    if (state.blocks.length >= 30) { showMsg($("warn"), "Tu peux ajouter jusqu’à 30 blocs dans cette maquette.", true); return; }
    var id = "block_" + Date.now();
    while (state.blocks.some(function (b) { return b.id === id; })) id = "block_" + (Number(id.slice(6)) + 1);
    state.blocks.push({ id: id, type: type });
    state.content[id] = type === "button" ? "Nouveau bouton" : type === "shape" ? "" : "Ton nouveau texte";
    if (type === "shape") state.blockStyles[id] = { backgroundColor: "#38d6b0", radius: 16 };
    selectedKey = id; render(); saveDraft();
  }
  function addImage(file) {
    if (!/^image\/(png|jpeg|webp)$/.test(file.type)) { showMsg($("warn"), "Choisis une image PNG, JPG ou WebP.", true); return; }
    if (file.size > 5 * 1024 * 1024) { showMsg($("warn"), "Image trop volumineuse : 5 Mo maximum avant optimisation.", true); return; }
    var used = Object.keys(state.imageData).reduce(function (n, k) { return n + state.imageData[k].length; }, 0);
    if (Object.keys(state.imageData).length >= 3 || used >= 450000) { showMsg($("warn"), "Limite atteinte : 3 images maximum et 450 Ko au total après optimisation.", true); return; }
    var reader = new FileReader();
    reader.onload = function () {
      var image = new Image();
      image.onload = function () {
        var scale = Math.min(1, 1000 / Math.max(image.width, image.height));
        var canvas = document.createElement("canvas"); canvas.width = Math.max(1, Math.round(image.width * scale)); canvas.height = Math.max(1, Math.round(image.height * scale));
        var ctx = canvas.getContext("2d"); ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
        var data = canvas.toDataURL("image/webp", 0.72);
        var total = Object.keys(state.imageData).reduce(function (n, k) { return n + state.imageData[k].length; }, 0) + data.length;
        if (data.length > 300000 || total > 450000) { showMsg($("warn"), "Cette image reste trop volumineuse après optimisation. Essaie une image plus légère.", true); return; }
        var id = "block_" + Date.now();
        state.blocks.push({ id: id, type: "image" }); state.imageData[id] = data; state.imageWidths[id] = 60; state.content[id] = file.name.slice(0, 80);
        selectedKey = id; showMsg($("warn"), "Image ajoutée et optimisée.", false); render(); saveDraft();
      };
      image.onerror = function () { showMsg($("warn"), "Impossible de lire cette image.", true); };
      image.src = reader.result;
    };
    reader.onerror = function () { showMsg($("warn"), "La lecture du fichier a échoué.", true); };
    reader.readAsDataURL(file);
  }

  function moveSectionImage(section, index, direction) {
    var images = state.sectionImages[section];
    var target = index + direction;
    if (!images || target < 0 || target >= images.length) return;
    var current = images[index]; images[index] = images[target]; images[target] = current;
    change(true);
  }

  function applySectionImageSizing(section) {
    var settings=state.sectionImageSettings[section];
    var selector=section==="galerie" ? ".pv-gallery-image" : ".pv-product-image";
    $("pv").querySelectorAll(selector).forEach(function(img){img.style.height=settings.height+"px";img.style.objectFit=settings.fit;});
  }

  function addSectionImages(section, files) {
    if (!files || !files.length) return;
    var accepted = Array.prototype.slice.call(files).filter(function (f) { return /^image\/(png|jpeg|webp)$/.test(f.type); });
    if (!accepted.length) { showMsg($("warn"), "Choisis des images PNG, JPG ou WebP.", true); return; }
    var current = state.sectionImages[section] || [];
    var room = 8 - current.length;
    if (room <= 0) { showMsg($("warn"), "Maximum 8 images pour cette section.", true); return; }
    if (accepted.length > room) accepted = accepted.slice(0, room);
    var pending = accepted.length, added = 0, failed = false;
    accepted.forEach(function (file) {
      if (file.size > 5 * 1024 * 1024) { pending--; failed = true; if (!pending) finish(); return; }
      var reader = new FileReader();
      reader.onload = function () {
        var image = new Image();
        image.onload = function () {
          var scale = Math.min(1, 900 / Math.max(image.width, image.height));
          var canvas = document.createElement("canvas"); canvas.width = Math.max(1, Math.round(image.width * scale)); canvas.height = Math.max(1, Math.round(image.height * scale));
          canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
          var data = canvas.toDataURL("image/webp", 0.65);
          var total = Object.keys(state.sectionImages).reduce(function (n, key) { return n + (state.sectionImages[key] || []).reduce(function (m, v) { return m + v.length; }, 0); }, 0);
          if (data.length < 140000 && total + data.length < 650000) { state.sectionImages[section].push(data); added++; } else failed = true;
          pending--; if (!pending) finish();
        };
        image.onerror = function () { failed = true; pending--; if (!pending) finish(); };
        image.src = reader.result;
      };
      reader.onerror = function () { failed = true; pending--; if (!pending) finish(); };
      reader.readAsDataURL(file);
    });
    function finish() { buildControls(); render(); saveDraft(); showMsg($("warn"), added + " image(s) ajoutée(s)." + (failed ? " Certaines images n’ont pas pu être ajoutées (format, taille ou espace)." : ""), failed); }
  }

  function addBrandLogo(file) {
    if (!/^image\/(png|jpeg|webp)$/.test(file.type)) { showMsg($("warn"), "Choisis un logo PNG, JPG ou WebP.", true); return; }
    if (file.size > 5 * 1024 * 1024) { showMsg($("warn"), "Logo trop volumineux : 5 Mo maximum.", true); return; }
    var reader = new FileReader();
    reader.onload = function () {
      var image = new Image();
      image.onload = function () {
        var scale = Math.min(1, 700 / Math.max(image.width, image.height));
        var canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
        var data = canvas.toDataURL("image/webp", 0.78);
        if (data.length > 220000) { showMsg($("warn"), "Ce logo est trop lourd. Essaie une image plus légère.", true); return; }
        state.brandLogo = data; state.brandMode = "logo";
        change(true); showMsg($("warn"), "Logo ajouté à l’identité de ton entreprise.", false);
      };
      image.onerror = function () { showMsg($("warn"), "Impossible de lire ce logo.", true); };
      image.src = reader.result;
    };
    reader.onerror = function () { showMsg($("warn"), "La lecture du logo a échoué.", true); };
    reader.readAsDataURL(file);
  }

  function bindBlockDragging() {
    var drag = null, resize = null, host = $("pv");
    host.addEventListener("pointerdown", function (event) {
      var handle = event.target.closest(".pv-resize-handle");
      if (handle && event.button === 0) {
        var item = handle.closest("[data-block-id]");
        if (!item) return;
        event.preventDefault(); event.stopPropagation();
        selectedKey = item.dataset.blockId;
        var rect = item.getBoundingClientRect();
        resize = { id: selectedKey, item: item, pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, w: rect.width, h: rect.height, moved: false };
        item.classList.add("is-resizing");
        if (handle.setPointerCapture) handle.setPointerCapture(event.pointerId);
        updateInspector();
        return;
      }
      var node = event.target.closest("[data-block-id]");
      if (!node || event.button !== 0) return;
      selectedKey = node.dataset.blockId;
      var pos = state.blockPositions[selectedKey] || { x: 0, y: 0 };
      drag = { id: selectedKey, node: node, pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, x: pos.x, y: pos.y, moved: false };
      node.classList.add("is-selected", "is-dragging");
      if (node.setPointerCapture) node.setPointerCapture(event.pointerId);
      updateInspector();
      event.preventDefault();
    });
    host.addEventListener("pointermove", function (event) {
      if (resize && event.pointerId === resize.pointerId) {
        var rw = Math.max(48, Math.min(1200, resize.w + event.clientX - resize.startX));
        var rh = Math.max(40, Math.min(900, resize.h + event.clientY - resize.startY));
        if (Math.abs(rw - resize.w) + Math.abs(rh - resize.h) > 2) resize.moved = true;
        resize.item.style.width = rw + "px"; resize.item.style.height = rh + "px";
        var inner = resize.item.querySelector("[data-editable]");
        if (inner && inner.tagName === "IMG") { inner.style.width = "100%"; inner.style.height = "100%"; }
        return;
      }
      if (!drag || event.pointerId !== drag.pointerId) return;
      var dx = event.clientX - drag.startX, dy = event.clientY - drag.startY;
      if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
      if (!drag.moved) return;
      var x = Math.max(-1200, Math.min(1200, drag.x + dx));
      var y = Math.max(-1200, Math.min(1200, drag.y + dy));
      drag.node.style.transform = "translate3d(" + x + "px," + y + "px,0)";
    });
    function finish(event) {
      if (resize && (!event || event.pointerId === resize.pointerId)) {
        var item = resize.item;
        if (resize.moved) state.blockSizes[resize.id] = { w: Math.round(item.getBoundingClientRect().width), h: Math.round(item.getBoundingClientRect().height) };
        item.classList.remove("is-resizing"); resize = null; saveDraft(); updateInspector(); return;
      }
      if (!drag || (event && event.pointerId !== drag.pointerId)) return;
      if (drag.moved) {
        var dx = event.clientX - drag.startX, dy = event.clientY - drag.startY;
        state.blockPositions[drag.id] = { x: Math.max(-1200, Math.min(1200, drag.x + dx)), y: Math.max(-1200, Math.min(1200, drag.y + dy)) };
        saveDraft();
      }
      drag.node.classList.remove("is-dragging");
      drag = null;
      updateInspector();
    }
    host.addEventListener("pointerup", finish);
    host.addEventListener("pointercancel", finish);
  }
  function selectedBlockIndex() { return state.blocks.findIndex(function (b) { return b.id === selectedKey; }); }
  function deleteSelectedBlock() {
    var i = selectedBlockIndex(); if (i < 0) return;
    var key = state.blocks[i].id;
    state.blocks.splice(i, 1); delete state.content[key]; delete state.elementColors[key]; delete state.blockOffsets[key]; delete state.blockPositions[key]; delete state.blockSizes[key]; delete state.blockStyles[key]; delete state.imageStyles[key]; delete state.imageData[key]; delete state.imageWidths[key];
    selectedKey = null; render(); saveDraft();
  }

  async function send() {
    var warn = $("warn"), btn = $("sendBtn");
    if (!window.cfgOk) return showMsg(warn, "Configuration manquante : renseigne config.js.", true);
    var s = (await sb.auth.getSession()).data.session;
    if (!s) { saveDraft(); location.href = "connexion.html?next=studio.html"; return; }
    var user = s.user; btn.disabled = true; showMsg(warn, "Envoi en cours…", false);
    try {
      var meta = user.user_metadata || {}, who = meta.full_name || meta.name || (user.email || "").split("@")[0] || "Client";
      var kind = ({ site: "site Web", app: "application", cv: "CV", poster: "affiche" })[state.type] || "projet";
      var snap = exportState(), images = collectImages(snap);
      var link = location.href.replace(/[?#].*$/, "").replace(/[^/]*$/, "") + "studio.html?d=" + await enc(stripImages(snap));
      var secs = state.sections.map(function (k) { return SEC[state.type][k]; }).join(", ");
      var label = ({ site: "Sections : ", app: "Écrans : ", cv: "Rubriques : ", poster: "Composition : " })[state.type] || "Éléments : ";
      var head = ["📋 Demande de devis", "Nom : " + who];
      if (meta.phone) head.push("Téléphone : " + meta.phone);
      head.push("Service : Maquette " + kind + " (studio)", "Budget : À discuter", "Délai : À discuter");
      var rows = ["Maquette " + kind + " créée dans le studio de design", "Modèle : " + TPL[state.type][state.template].label, "Nom du projet : " + (state.name || "—"), "Slogan : " + (state.slogan || "—"), "Couleur : " + state.color, "Thème : " + (state.theme === "dark" ? "sombre" : "clair"), "Police : " + FONTS[state.font][0], "Coins : " + RADII[state.radius][0], label + secs];
      if (state.type === "poster" && state.canvas && Array.isArray(state.canvas.els)) {
        var tx = state.canvas.els.filter(function (e) { return e.k === "t" && e.tx && e.tx.trim(); }).slice(0, 6).map(function (e) { return e.tx.replace(/\s+/g, " ").trim().slice(0, 50); });
        if (tx.length) rows.push("Textes de l’affiche : " + tx.join(" / "));
      }
      if (images.length) rows.push("Images : " + images.length + " jointe(s) à la conversation");
      var tail = "\nVoir la maquette : " + link, base = head.concat(["Projet : " + rows[0]], rows.slice(1)).join("\n") + tail;
      var notes = state.notes ? String(state.notes) : "", room = 1950 - base.length - 14;
      if (notes && room > 20) { if (notes.length > room) notes = notes.slice(0, room - 1) + "…"; rows.push("Remarques : " + notes); }
      var body = head.concat(["Projet : " + rows[0]], rows.slice(1)).join("\n") + tail;
      var subject = ("Devis · Maquette " + kind + " (studio) · " + who).slice(0, 120);

      /* Envoi par la messagerie du site (fonction « chat »), avec repli direct si besoin */
      async function post(text, cid) {
        try {
          var r = await sb.functions.invoke("chat", { body: cid ? { action: "send", conversation_id: cid, body: text } : { action: "send", subject: subject, body: text } });
          if (!r.error && r.data && r.data.message) return r.data.message.conversation_id;
        } catch (e) {}
        if (!cid) {
          var c = await sb.from("conversations").insert({ customer_id: user.id, subject: subject }).select("id").single();
          if (c.error) throw new Error(c.error.message);
          cid = c.data.id;
        }
        var m = await sb.from("messages").insert({ conversation_id: cid, sender_id: user.id, body: text });
        if (m.error) throw new Error(m.error.message);
        return cid;
      }
      var cid = await post(body);

      if (images.length) {
        var ok = [], failed = 0;
        for (var i = 0; i < images.length; i++) {
          var path = user.id + "/" + Date.now() + "-studio-" + i + ".webp";
          var up = await sb.storage.from("project-files").upload(path, dataToBlob(images[i].data), { contentType: "image/webp", upsert: false });
          if (up.error) failed++; else ok.push({ path: path, name: images[i].name });
        }
        try {
          if (ok.length) await post(ok.map(function (x) { return "[[file:" + x.path + "|" + x.name + "]]"; }).join("\n"), cid);
          if (failed) await post("ℹ️ " + failed + " image(s) de la maquette n’ont pas pu être jointes automatiquement : je te les envoie ici dans le chat.", cid);
        } catch (e) {}
      }
      try { localStorage.removeItem(KEY); } catch (e) {}
      location.href = "espace.html?open=" + encodeURIComponent(cid);
    } catch (err) {
      showMsg(warn, "Maquette non envoyée : " + (err && err.message ? err.message : "erreur inconnue"), true);
    } finally { btn.disabled = false; }
  }

  (async function start() {
  var d = new URLSearchParams(location.search).get("d"), shared = false, raw = null;
  if (d) { try { raw = await dec(d); state = clean(raw); shared = true; } catch (e) { state = null; raw = null; showMsg($("warn"), "Ce lien de maquette n’est pas valide. Ton propre brouillon est affiché.", true); } }
  if (!state) { raw = null; state = defaults("site"); }
  if (shared) initPages(raw); else { pages = []; activePageId = null; }
  if (shared) { $("sharedNote").hidden = false; }

  bind();
  document.querySelectorAll("[data-studio-service]").forEach(function (button) {
    button.addEventListener("click", function () { openStudioService(button.dataset.studioService); });
  });
  $("studioBackHub").addEventListener("click", showStudioHub);
  if (shared) {
    $("studioServiceHub").hidden = true; $("controls").hidden = false; $("studioBackHub").hidden = false;
    setStudioWorkspace(state.type);
    buildControls(); render(); renderPages();
  } else {
    $("studioServiceHub").hidden = false; $("controls").hidden = true; $("studioBackHub").hidden = true;
  }
  if (window.cfgOk) sb.auth.getSession().then(function (r) { var u = r.data.session && r.data.session.user; if (u && u.id === STROMTECH.ADMIN_ID) { $("sendBtn").hidden = true; } });
  })();
})();
